"""
File:pa09.py
Author: Michael Riesberg-Timmer
Description: print top 10 players based on points, minutes played,
             rebounds, and efficiency
"""

#Function: main
#Inputs: no inputs
#output: top ten players in each category
#Description: runs other functions to create lists in each catgegory
#             then sort those lists and print them from highest to lowest
def main():
    #grab master list
    masterList = readData()

    #creates list of players and their points
    ptsList = points(masterList)
    print("Top 10 players based on total points scored.")
    #organize players
    ptsList.sort()
    #grab top 10 players in list of 4051 players
    topPtsList = ptsList[4041:]
    #print top 10 players
    topPtsList.reverse()
    for player in topPtsList:
        print(player[1],player[2],"-",player[0])
        
    print("\n")
    
    #creates list of players and their minutes played
    mtsList = minutes(masterList)
    print("Top 10 players based on total minutes played.")
    #organize players
    mtsList.sort()
    #grab top 10 players in list of 4051 players
    topMtsList = mtsList[4041:]
    #print top 10 players
    topMtsList.reverse()
    for player in topMtsList:
        print(player[1],player[2],"-",player[0])

    print("\n")
    
    #creates list of players and their total rebounds
    rbdList = rebounds(masterList)
    print("Top 10 players based on total rebounds.")
    #organize players
    rbdList.sort()
    #grab top 10 players in list of 4051 players
    topRbdList = rbdList[4041:]
    #print top 10 players
    topRbdList.reverse()
    for player in topRbdList:
        print(player[1],player[2],"-",player[0])

    print("\n")

    #creates list of players and their efficiency
    effList = efficiency(masterList)
    print("Top 10 players based on efficiency.")
    #organize players
    effList.sort()
    #grab top 10 players in list of 4051 players
    topEffList = effList[4041:]
    #print top 10 players
    topEffList.reverse()
    for player in topEffList:
        print(player[1],player[2],"-",player[0])
    

#Function: readData
#Inputs: no inputs
#output: returns master list with every player and all their stats
#Description: creates master list for every other function to access  
def readData():
    masterList = []
    fin = open("player_career.csv","r")
    fin.readline()
    for line in fin:
        line = line.replace(" ","")
        line = line.replace("\n","")
        tempList = line.split(",")
        masterList.append(tempList)
    masterList = masterList[:-3]
    return masterList
    fin.close()

#Function: points
#Inputs: list
#output: list of each player and their number of points
#Description: creates a list of each player and their number of points
def points(masterList):
    ptsList = []
    for player in masterList:
        tempList = [int(player[6]),player[1],player[2]]
        ptsList.append(tempList)
    return ptsList
        
#Function: minutes
#Inputs: list
#output: list of each player and their number of minutes played
#Description: creates a list of each player and their number of minutes played        
def minutes(masterList):
    mtsList = []
    for player in masterList:
        tempList = [int(player[5]),player[1],player[2]]
        mtsList.append(tempList)
    return mtsList

#Function: rebounds
#Inputs: list
#output: list of each player and their number of rebounds
#Description: creates a list of each player and their number of rebounds
def rebounds(masterList):
    rbdList = []
    for player in masterList:
        tempList = [int(player[9]),player[1],player[2]]
        rbdList.append(tempList)
    return rbdList

#Function: efficiency
#Inputs: list
#output: list of each player and their efficiency
#Description: creates a list of each player and their efficiency
#             after calculating efficiency 
def efficiency(masterList):
    effList = []
    for player in masterList:
        (ilkid,firstname,lastname,leag,gp,minutes,pts,oreb,dreb,reb,
        asts,stl,blk,turnover,pf,fga,fgm,fta,ftm,tpa,tpm) = (0,1,2,3,
                        4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20)
        
        efficiency = ((float(player[pts])+float(player[reb])+
                       float(player[asts])+float(player[stl])+
                       float(player[blk]))-((float(player[fga])
                    -float(player[fgm]))+(float(player[fta])-float(player[ftm]))
                    +float(player[turnover])))/float(player[gp])

        tempList = [efficiency,player[1],player[2]]
        effList.append(tempList)
    return effList
    
    
