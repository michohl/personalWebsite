"""
File: squares.py
Author: Michael Riesberg-Timmer
Description: Print a latin square based off of user inputs
"""

#set program loop condition
Loop = True

#input from user (create verification loop later)
while Loop == True:
    OrderStr = input("Please input the order of square: ")
    while not OrderStr.isdigit():
        print("Number must be a positive integer. Please try again.")
        OrderStr = input("Please input the order of square: ")

    TopLeftStr = input("Please input the top left number: ")
    while True:
        if not TopLeftStr.isdigit():
            print("Number must be a positive integer. Please try again.")
            TopLeftStr = input("Enter a single digit: ")

        if int(TopLeftStr) > int(OrderStr):
            print("Number must be a positive integer less than order." '\n'
                  "Please try again.")
            TopLeftStr = input("Enter a single digit: ")
        else:
            break

#initialize counters and make inputs integers
    OrderInt = int(OrderStr)
    TopLeftInt = int(TopLeftStr)
    LatinNumber = TopLeftInt

#prints rows up to orderint
    for rows in range(1,OrderInt+1):    
        for columns in range(1,OrderInt+1):
            if LatinNumber > OrderInt:
                LatinNumber = LatinNumber % OrderInt
                print(LatinNumber,end=' ')
                LatinNumber += 1
            elif LatinNumber <= OrderInt:
                print(LatinNumber,end=' ')
                LatinNumber += 1
			
            else:
                break
        LatinNumber += 1
        print()

    LoopOrNot = input("Would you like to continue? (y/n)")
    if LoopOrNot == "n":
        Loop = False
        print("Goodbye...")
    elif LoopOrNot == "y":
        Loop = True
            

