"""
File: pa07.py
Author: Michael Riesberg-Timmer
Description: Convert words and sentences to pig latin
"""

#Function findFirstVowel
#Inputs: one word string
#output: index value of first vowel in word
#Description: Finds index value of first vowel in word

def findFirstVowel(string):
    """Enter variable with string or string in quotes"""
    vowels = ['a','e','i','o','u']
    counter = -1
    for char in string:
        counter += 1
        if char.lower() in vowels:
            return counter
    return -1

#Function translateWord
#Inputs: one word string
#output: word translated into pig latin
#Description: translates word into pig latin

def translateWord(string):
    """Enter a single word"""
    consonants = ['b','c','d','f','g','h','j','k','l','m','n','p','q','r',
                  's','t','v','x','z']
    vowels = ['a','e','i','o','u','w','y']
    firstVowelIndex = int(findFirstVowel(string))
    output = ""
    if firstVowelIndex == -1:
        output = string
        return string
    if string.lower()[0] in consonants:       
        string1 = string[:firstVowelIndex]
        string2 = string[firstVowelIndex:]
        output += string2 + string1 + "ay"

    elif string.lower()[0] in vowels:
        output += string + "way"
        return output
        
    return output

#Function pigLatinTranslator
#Inputs: Sentence ending in a period
#output: Sentence translated into pig latin with first letter capitalized
#        and period added to the end
#Description: Translates sentence to pig latin

def pigLatinTranslator(string):
    """Enter a sentence ending with a period"""
    output = ""
    newString = string[:-1] #removes period from sentence
    wordList = newString.split(" ")
    for word in wordList:
        output += translateWord(word).lower() + " "

    outputSlice1 = output[0].upper()
    outputSlice2 = output[1:-1] + "."
    output = outputSlice1 + outputSlice2
    
    return output
        
#input from user
stringToTranslate = input("Enter a sentence ending with a period: ")

#translations
print(pigLatinTranslator(stringToTranslate))

#leave window up before program closes
input("Press any key to exit.")


###TESTING FUNCTIONS###
#testing findFirstVowel function
string = "hhhh"
expected = -1
result = findFirstVowel(string)
if not result == expected:
    print("whoopsies #1")

string = "hhhhi"
expected = 4
result = findFirstVowel(string)
if not result == expected:
    print("whoopsies #2")


#testing translateWord function 
string = "hello"
expected = "ellohay"
result = translateWord(string)
if not result == expected:
    print("whoopsies #3")

string = "am"
expected = "amway"
result = translateWord(string)
if not result == expected:
    print("whoopsies #4")

string = "tv"
expected = "tv"
result = translateWord(string)
if not result == expected:
    print("whoopsies #5")

#testing pigLatinTranslator function
string = "This is my absolute favorite assignment."
expected = "Isthay isway my absoluteway avoritefay assignmentway."
result = pigLatinTranslator(string)
if not result == expected:
    print("whoopsies #6")
