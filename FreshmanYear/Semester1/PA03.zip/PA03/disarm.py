"""
File: disarm.py
Author: Michael Riesberg-Timmer
Description: Add all odd fibonacci numbers under four million to find
             the code to defuse the bomb
"""

#initializing
SumOfOdds = 0
last,current = 0,1

#Calculation
while current < 4000000:
    last,current = current, last+current
    if last % 2:
        continue
    SumOfOdds += last

#printing the code
print("The code to defuse the bomb is",str(SumOfOdds)+"!")
