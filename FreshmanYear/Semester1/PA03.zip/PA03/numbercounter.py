"""
File: numbercounter.py
Author: Michael Riesberg-Timmer
Description: Compute the number of times a given digit appears in a given number
"""



#Check input value taken from user
LargeNumber = input("enter a positive integer: ")
while not LargeNumber.isdigit():
    print("Numbers must be a positive integer. Please try again.")
    LargeNumber = input("Enter a positive number: ")
LargeNumberOriginal = LargeNumber

SmallNumber = input("Enter a single digit: ")
while True:
    if not SmallNumber.isdigit():
        print("Please enter a digit in the range 0 through 9 (inclusive)")
        SmallNumber = input("Enter a single digit: ")

    if int(SmallNumber) >= 10:
        print("Please enter a digit in the range 0 through 9 (inclusive)")
        SmallNumber = input("Enter a single digit: ")
    else:
        break


#Initialize
total = 0

#Change strings to ints to make my life easy
LargeNumber = int(LargeNumberOriginal)
SmallNumber = int(SmallNumber)

#calculations
while LargeNumber:
    Remainder = LargeNumber % 10
    LargeNumber = LargeNumber // 10
    if Remainder == SmallNumber:
        total += 1
print(LargeNumberOriginal,"contains a total of",total, str(SmallNumber)+"s")



