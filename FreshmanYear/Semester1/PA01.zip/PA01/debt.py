"""
File: debt.py
Author: Michael Riesberg-Timmer
Description: To describe the debt
"""

#Gaining information
NationalDebtString = input("What is the current national debt: ")
NationalDebtInterger = int(NationalDebtString)

DenominationString = input("What denomination of currency: ")
DenominationInterger = int(DenominationString)

#Calculations

NumberOfBills = NationalDebtInterger/DenominationInterger

HeightInches = NumberOfBills * 0.0043

HeightMiles = HeightInches / 63360

DistanceFromMoon = HeightMiles / 238857

#Printing
print("The debt",NationalDebtInterger," has a height in miles of",DenominationInterger,"'s,", \
      HeightMiles)
print("That is",DistanceFromMoon," times the average distance from the earth to the moon!")
