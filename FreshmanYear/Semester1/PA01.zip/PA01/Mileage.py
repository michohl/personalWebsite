"""
File: Mileage.py
Author: Michael Riesberg-Timmer
Description: compare mileage between two cars
"""

#Gaining information
MilesStartingString = input("What mile did your odometer start at :")
MilesStartingInterger = int(MilesStartingString)

MilesEndString = input("What mile did your odometer end at :")
MilesEndInterger = int(MilesEndString)

GasString = input("How many gallons of gas was used for this trip :")
GasInterger = int(GasString)

#Calculations
MilesTraveled = MilesEndInterger - MilesStartingInterger
MPG = MilesTraveled / GasInterger

#Printing
print("Your car is getting",MPG,"miles to the gallon")

                        
