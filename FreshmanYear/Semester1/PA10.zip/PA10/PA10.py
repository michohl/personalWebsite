"""
File: PA10.py
Author: Michael Riesberg-Timmer
Description: Create a word cloud from debates 
"""

import string

def printHTMLfile(body,title):
    ''' create a standard html page with titles, header etc.
    and add the body (an html box) to that page. File created is title+'.html'
    '''
    fd = open(title+'.html','w')
    theStr="""
    <!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML//EN">
    <html> <head>
    <title>"""+title+"""</title>
    </head>

    <body>
    <h1>"""+title+'</h1>'+'\n'+body+'\n'+"""<hr>
    <address></address>
    <!-- hhmts start --> Last modified: November 2015 <!-- hhmts end -->
    </body> </html>
    """
    fd.write(theStr)
    fd.close()

def makeHTMLbox(body):
    ''' make an HTML box that has all the words in it
    '''
    boxStr = """<div style=\"
    width: 800px;
    background-color: rgb(250,250,250);
    border: 1px grey solid;
    text-align: center\">%s</div>
    """
    return boxStr % (body)

def makeHTMLword(word,cnt,high,low):
    ''' make a word with a font size to be placed in the box. Font size is scaled
    between htmlBig and htmlLittle (to be user set). high and low represent the high 
    and low counts in the document. cnt is the cnt of the word 
    '''
    htmlBig = 96
    htmlLittle = 14
    ratio = (cnt-low)/float(high-low)
    fontsize = htmlBig*ratio + (1-ratio)*htmlLittle
    fontsize = int(fontsize)
    wordStr = '<span style=\"font-size:%spx;\">%s</span> '
    return wordStr % (str(fontsize), word)

def main(file,speaker):
    wordDict = wordFrequency(file,speaker)
    top40 = topFortyWords(file,speaker)
    top40Alph = topFortyWordsAlphabatized(file,speaker)
    

    pairs = top40Alph
    highCount=top40[len(top40)-1][0]
    lowCount=top40[0][0]
    body=''
    for word,cnt in pairs:
        body = body + makeHTMLword(word,cnt,highCount,lowCount)
    box = makeHTMLbox(body)
    printHTMLfile(box,speaker)
    

def formatDebate(file,speaker):
    fin = open(file,"r")
    wordList = []
    specCharacters = "?.!/;:-,"
    stopWords = open("stopSQL.txt","r")
    StopSQL = []
    for line in stopWords:
        line = line.strip()
        StopSQL.append(line)
        
    for line in fin:
        line = line.split()

        if line == []:
            pass
        elif "(" in line[0] or ")" in line[0]:
            pass
        elif line[0] == speaker+":":
            for word in line[1:]:
                if not word.lower() in StopSQL:
                    for char in word:
                        if char in specCharacters:
                            word = word.replace(char,"")
                wordList.append(word.lower())
        elif not line[0] or not line == []:
            for word in line:
                if not word.lower() in StopSQL:
                    for char in word:
                        if char in specCharacters:
                            word = word.replace(char,"")
                wordList.append(word.lower())

    fin.close()
    stopWords.close()
    return wordList
            
            

def wordFrequency(file,speaker):
    wordDict = dict()
    wordList = formatDebate(file,speaker)
    specCharacters = "?.!/;:-,"
    for word in wordList:
        for char in word:
            if char in specCharacters:
                word = word.replace(char,"")        
        word = word.strip()
        word = word.lower()
        if not word in wordDict:
            wordDict[word]=1
        if word in wordDict:
            wordDict[word]+=1
    del wordDict[""]
    return wordDict


def topFortyWords(file,speaker):
    stopWords = open("stopSQL.txt","r")
    StopSQL = []
    for line in stopWords:
        line = line.strip()
        StopSQL.append(line)
        
    wordDict = wordFrequency(file,speaker)
    wordList = []
    for word in wordDict:
        if not word in StopSQL:
            wordList.append([wordDict[word],word])
    wordList.sort()
    wordList = wordList[len(wordList)-40:]

    return wordList

def topFortyWordsAlphabatized(file,speaker):
    top40 = topFortyWords(file,speaker)
    for item in top40:
        item.reverse()
    top40.sort()

    return top40
    
