"""
File: PA11.py
Author: Michael Riesberg-Timmer
Description: Decode files
"""

#Function: decode
#Inputs: name of input file and desired output file name
#Outputs: File with decoded copy of file
#Description: decrypts a encrypted file and creates new file with output

def decode(inputfile,outputfile):
    fin = open(inputfile,"r")
    fout = open(outputfile,"w")

    #constants to do subtraction for pennymath values
    ASCII_SUBTRACTION_LOWER = 96
    ASCII_SUBTRACTION_UPPER = 64

    #create string with text from file
    text = fin.read()
    
    skip = 0
    output = ""
    for char in text:
        #print(char,"---",skip)
        if skip == 0:
            output += char
            if char.isupper():
                skip = (ord(char) - ASCII_SUBTRACTION_UPPER)
            elif char.islower():
                skip = (ord(char) - ASCII_SUBTRACTION_LOWER)
            elif char.isnumeric():
                skip = int(char)
            else:
                skip = 6
        else: 
            skip -= 1
    
    fout.write(output)       

        
    #I don't always forget to close the files
    fin.close()
    fout.close()


