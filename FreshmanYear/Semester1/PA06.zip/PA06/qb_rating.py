"""
File: qb_rating.py
Author: Michael Riesberg-Timmer
Description: Make predicitions for fantasy football quarterbacks
"""

#connect to the file
fin = open("qb_data_2015.csv","r")
fout = open("qb_passer_ratings_2015.csv","w")

#create header for output file
fout.write("Player, attempts, completed passes, yards passed,"
           "touch downs passed, interceptions thrown, Rating, Prediction\n")

#skip the header when reading lines and assigning ariables
fin.readline()

for line in fin:
    player,team,comp,att,yds,long,inter,sack,td = line.split(",")
    CompletionStat = ((float(comp)/float(att))*100 - 30)/20
    YardsStat = ((float(yds)/float(att))-3)/4
    TouchdownStat = (float(td)/float(att))*20
    InterceptionsStat = 2.375 - ((float(inter)/float(att)) * 25)
    currentList = [player,td]
    print(currentList)

    if CompletionStat > 2.375:
        CompletionStat = 2.375
    elif CompletionStat < 0:
        copletionStat = 0
    if YardsStat > 2.375:
        YardsStat = 2.375
    elif YardsStat < 0:
        YardsStat = 0
    if TouchdownStat > 2.375:
        TouchdownStat = 2.375
    elif TouchdownStat < 0:
        TouchdownStat = 0
    if InterceptionsStat > 2.375:
        InterceptionsStat = 2.375
    elif InterceptionsStat < 0:
        INterceptionsStat = 0

    #calculate passing rating
    PassingRating = ((CompletionStat + YardsStat + TouchdownStat +
                      InterceptionsStat)/6 )*100

    if PassingRating <=85:
        Prediction = "Bad"
    elif PassingRating > 85 and PassingRating <= 90:
        Prediction = "Mediocre"
    elif PassingRating > 90 and PassingRating <= 95:
        Prediction = "Good"
    elif PassingRating > 95:
        Prediction = "Great"

    #write to file
    fout.write(player)
    fout.write(",")
    fout.write(str(att))
    fout.write(",")
    fout.write(str(comp))
    fout.write(",")
    fout.write(str(yds))
    fout.write(",")
    fout.write(str(td[:-1]))
    fout.write(",")
    fout.write(str(inter))
    fout.write(",")
    fout.write(str(PassingRating))
    fout.write(",")
    fout.write(Prediction)
    fout.write("\n")    
                     
fin.close()
fout.close()
