"""
File: Weight.py
Author: Michael Riesberg-Timmer
Description: Use BMI index to tell user if they are underweight, normal, overweight, or obese
"""

#Collect input for weight then height in pounds then inches
WeightStr = input("How much do you weigh in pounds? ")
HeightStr = input("How tall are you in inches? ")

#Convert inputs to float values
WeightFloat = float(WeightStr)
HeightFloat = float(HeightStr)

#Convert to kilograms and meters then calculate BMI
WeightKilo = WeightFloat * 0.453592
HeightMeters = (HeightFloat * 2.54)* 0.01

BMI = WeightKilo / HeightMeters**2

#Compare BMI to BMI index and print weight status with BMI
if BMI < 18.5:
    print("Your body mass index is",BMI, \
          "meaning you are underweight")
if (BMI >= 18.5) and (BMI < 25):
    print("Your body mass index is",BMI, \
          "meaning you are at a normal weight")
if (BMI >= 25) and (BMI < 30):
    print("Your body mass index is",BMI, \
          "meaning you are overweight")
if BMI > 30:
    print("Your body mass index is",BMI, \
          "meaning you are obese")
