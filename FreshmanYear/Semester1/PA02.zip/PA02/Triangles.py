"""
File: Triangles.py
Author: Michael Riesberg-Timmer
Description: Check if a triangle is legal and then if said triangle is a right
             triangle or not
"""

#Collect input from user (wow is identifying the 'middle side of a triangle awkward)
ShortStr = input("What is the length of the shortest side of the trinagle? ")
MedStr = input("What is the length of the second shortest side of the traingle? ")
LongStr = input("What is the length of the longest side of the triangle? ")

#Convert to floats
ShortFloat = float(ShortStr)
MedFloat = float(MedStr)
LongFloat = float(LongStr)

#Conditionals
if ShortFloat > MedFloat or MedFloat > LongFloat:
    print("Those three sides are not in the right order!")

elif LongFloat > ShortFloat + MedFloat:
    print("Those three sides do not make a valid triangle")
else:
    print("Those three sides do make a valid triangle")

if ShortFloat**2 + MedFloat**2 == LongFloat**2:
    print("Furthermore, those three sides are a right triangle")

    
