"""
File: rps_w_memory.py
Author: Michael Riesbeg-Timmer
Description: User plays rock paper scissors with a bot. Bot chooses it's answer according to user's input habits
"""

#import random library
import random
random.seed()

#assigning rock paper and scissors a value
Rock = 1
Paper = 2
Scissors = 3

#Counters
Wins = 0
Losses = 0
Ties = 0

RockCount = 0
PaperCount = 0
ScissorsCount = 0

#initializing loop for entire program
BigLoop = True

while BigLoop == True:
    #Bot making it's choice
    BotChoice = random.randint(1,3)

    #loop for user's input
    inputLoop = True

    #user makes their choice (also verify it is the correct choice)    
    while inputLoop == True:
        UserChoice = input("I've selected my weapon user. Now choose "+
                           "yours! \n"+
                           "Enter r for rock. \n"+
                           "Enter p for paper. \n"+
                           "Enter s for scissors. \n")
        #print()
        UserChoice = UserChoice.lower()
        if UserChoice == "r" or UserChoice == "p" or UserChoice == "s":
            inputLoop = False
        elif UserChoice == "q":
            inputLoop = False
        if UserChoice == "r" or UserChoice == "p" or UserChoice == "s":
            inputLoop = False
        elif UserChoice == "q":
            inputLoop = False
        else:
            print("That weapon is not allowed in this arena!"+
                  "Please choose another.")
    #Reassinging bots choice. Making it based on user
    if RockCount > PaperCount and RockCount > ScissorsCount:
        BotChoice = 2
    elif PaperCount > RockCount and PaperCount > ScissorsCount:
        BotChoice = 3
    elif ScissorsCount > RockCount and ScissorsCount > PaperCount:
        BotChoice = 1
    elif RockCount >= PaperCount > ScissorsCount:
        BotChoice = random.randint(1,2)
    elif ScissorsCount >= PaperCount > RockCount:
        BotChoice = random.randint(2,3)
    elif ScissorsCount >= RockCount > PaperCount:
        BotChoice = [1,3][random.randint(0,1)]
    else:
        BotChoice = random.randint(1,3)
    
    #giving user's choice a number value to compare to bot
    UserChoice = UserChoice.lower()
    if UserChoice == "r":
        UserChoiceNum = 1
        RockCount += 1
    elif UserChoice == "p":
        UserChoiceNum = 2
        PaperCount += 1
    elif UserChoice == "s":
        UserChoiceNum = 3
        ScissorsCount += 1
    elif UserChoice == "q":
        print()
        print("You have scored",Wins,"wins,",Losses,"losses, and "
              ,Ties,"ties!")
        BigLoop = False
        break

    #compare users input to bot's answer and see who wins
    if UserChoiceNum == BotChoice:
        Ties += 1
        print("We have tied!")
        if UserChoiceNum == 1:
            print("Our rocks cannot break each other!")
        elif UserChoiceNum == 2:
            print("Our papers can't seem to cover each other!")
        elif UserChoiceNum == 3:
            print("Our scissors can't seem to cut each other down!")
    elif UserChoiceNum > BotChoice:
        Wins += 1
        print("You have bested me... ")
        if UserChoiceNum == 1 and BotChoice == 3:
            print("Your rock has beaten down my scissors!")
        elif UserChoiceNum == 2 and BotChoice == 1:
            print("Your paper has completely blinded my rock!")
        elif UserChoiceNum == 3 and BotChoice == 2:
            print("Your scissors have cut down my paper!")
    elif UserChoiceNum < BotChoice:
        Losses += 1
        print("You have been defeated! ")
        if BotChoice == 1 and UserChoiceNum == 3:
            print("My rock has crushed your scissors!")
        elif BotChoice == 2 and UserChoiceNum == 1:
            print("My paper has covered your rock!")
        elif BotChoice == 3 and UserChoiceNum == 2:
            print("My scissors have slain your paper!")      
    print()
