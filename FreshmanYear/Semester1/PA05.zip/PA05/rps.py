"""
File: rps.py
Author: Michael Riesbefg-Timmer
Description: User plays rock paper scissors with a bot
"""

#import random library
import random
random.seed()

#assigning rock paper and scissors a value
Rock = 1
Paper = 2
Scissors = 3

#Counters
Wins = 0
Losses = 0
Ties = 0

#initializing loop for entire program
BigLoop = True

while BigLoop == True:
    #Bot making it's choice
    BotChoice = random.randint(1,3)

    #loop for user's input
    inputLoop = True

    #user makes their choice (also verify it is the correct choice)
    while inputLoop == True:
        UserChoice = input("I've selected my weapon user. Now choose yours!(r,p,s or q to quit) ")
        UserChoice = UserChoice.lower()
        if UserChoice == "r" or UserChoice == "p" or UserChoice == "s":
            inputLoop = False
        elif UserChoice == "q":
            inputLoop = False
        if UserChoice == "r" or UserChoice == "p" or UserChoice == "s":
            inputLoop = False
        elif UserChoice == "q":
            inputLoop = False
        else:
            print("That weapon is not allowed in this arena! Please choose another.")

    #giving user's choice a number value to compare to bot
    UserChoice = UserChoice.lower()
    if UserChoice == "r":
        UserChoiceNum = 1
    elif UserChoice == "p":
        UserChoiceNum = 2
    elif UserChoice == "s":
        UserChoiceNum = 3
    elif UserChoice == "q":
        print("You have scored",Wins,"wins,",Losses,"losses, and ",Ties,"ties!")
        BigLoop = False
        break

    #compare users input to bot's answer and see who wins
    if UserChoiceNum == BotChoice:
        Ties += 1
        print("We have tied!")
    elif UserChoiceNum > BotChoice:
        Wins += 1
        print("You have bested me... ")
    elif UserChoiceNum < BotChoice:
        Losses += 1
        print("You have been defeated! ")
