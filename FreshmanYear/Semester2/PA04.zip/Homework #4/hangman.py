"""
File: hangman.py
Author: Michael Riesberg-Timmer
description: Play a game of hangman
"""

from random import randint

def main(file):
    wordDict = createWordDict(file)
    wordLengthChoice = userChoices("l",wordDict)
    guessAmmountChoice = userChoices("a",wordDict)
    secretWord = wordChoice(wordDict,wordLengthChoice)
    gameTime(guessAmmountChoice,secretWord)
        

def createWordDict(file):
    finalDict = dict()
    myFile = open(file,"r")
    for line in myFile:
        line = str(line)
        tempLength = (len(line)+1)-2
        if tempLength in finalDict.keys():
            finalDict[tempLength].append(line.replace("\n",""))
        else:
            finalDict[tempLength]=[]
            finalDict[tempLength].append(line.replace("\n",""))  
    return finalDict 

def userChoices(lengthOrAmmount,wordDict):
    if lengthOrAmmount == "l":
        wordLengthChoice = int(input("Enter the desired length of the word: "))
        while wordLengthChoice == 0 or wordLengthChoice not in wordDict.keys():
            wordLengthChoice = int(input("That length is not avialable. Enter the desired length of the word: "))
        return wordLengthChoice
    elif lengthOrAmmount == "a":
        guessAmmountChoice = int(input("Enter the desired number of guesses: "))
        while guessAmmountChoice <= 0:
            guessAmmountChoice = int(input("That is not a valid number of guesses. Enter the desired number of guesses(positive number): "))
        return guessAmmountChoice

def wordChoice(wordDict,wordLengthChoice):
    secretWord = wordDict[wordLengthChoice]
    randomChoice = randint(0,len(secretWord))
    return secretWord[randomChoice]

def gameTime(guessAmmountChoice,secretWord):
    guessedLetters = []
    for numberOfGuesses in range(guessAmmountChoice,-1,-1):
        missingLetters = len(secretWord)
        if numberOfGuesses == 0:
            print("You've run out of guesses. You lose.")
            print("The word was", secretWord)
            break


        for letter in secretWord:
            if letter in guessedLetters:
                print(letter,end=' ')
                missingLetters -= 1
            else:
                print("_ ",end='')                
        print("\n")

        if missingLetters == 0:
            print(secretWord)
            print("You've figured the word out!")
            print("It took you", guessAmmountChoice-numberOfGuesses, "attempts!")
            input("Press any key to close")
            break

                
        tempGuess = str((input("Enter a letter: ")))
        while not tempGuess.isalpha() or len(tempGuess) != 1 or tempGuess in guessedLetters:
            if not tempGuess in guessedLetters:
                tempGuess = str(input("Enter a single letter: "))
            if tempGuess in guessedLetters:
                tempGuess = str(input("Enter a single letter you have not already guessed: "))

        
        if tempGuess in secretWord:
            print("You've guessed correctly!")
            guessedLetters.append(tempGuess)
        else:
            print("You've guessed incorrectly.")
            guessedLetters.append(tempGuess)
        

main("dictionary.txt")
