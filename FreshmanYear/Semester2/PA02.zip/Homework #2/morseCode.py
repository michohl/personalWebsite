"""
File: morseCode.py
Author: Michael Riesberg-Timmer
Description: Allow user to both encrypt and decrypt strings
"""
from os.path import exists
def main():
    """ main is the outline for our program. It begins by creating both a
    normal dictionary with keys and values being charaters and morse code
    respectively. Then it asks the user if they want to decrypt or enrypt or
    exit."""
    charToMorseCodeDictionary = charToMorseCodeDict()
    morseCodeToCharDictionary = morseCodeToCharDict(charToMorseCodeDictionary)
    action = encryptOrDecrypt()
    if action.lower() == "e":
        encrypt(charToMorseCodeDictionary)
    elif action.lower() == "d":
        decrypt(morseCodeToCharDictionary)
    else:
        exit()

def charToMorseCodeDict():
    """Creates a dictionary where the value is the morse code and the
    key is the character used to make that morse code"""
    return {
    '.':'.-.-.-',
    ',':'--..--',
    '?':'..--..',
    ':':'---...',
    '@':'.--.-.',
    '/':'-..-.',
    '-':'-....-',
    '\'':'.-----.',
    '"':'.-..-.',
    '=':'-...-',
    '(':'-.--.',
    ')':'-.--.-',
    '\n':'.-.-',
    '0':'-----',
    '1':'.----',
    '2':'..---',
    '3':'...--',
    '4':'....-',
    '5':'.....',
    '6':'-....',
    '7':'--...',
    '8':'---..',
    '9':'----.',
    'A':'.-',
    'B':'-...',
    'C':'-.-.',
    'D':'-..',
    'E':'.',
    'F':'..-.',
    'G':'--.',
    'H':'....',
    'I':'..',
    'J':'.---',
    'K':'-.-',
    'L':'.-..',
    'M':'--',
    'N':'-.',
    'O':'---',
    'P':'.--.',
    'Q':'--.-',
    'R':'.-.',
    'S':'...',
    'T':'-',
    'U':'..-',
    'V':'...-',
    'W':'.--',
    'X':'-..-',
    'Y':'-.--',
    'Z':'--..' }

def morseCodeToCharDict(charToMorseCodeDictionary):
    """Creates a dictionary opposite of our original dictionary. This dictionary
    uses the morse code as the key and the charater as the value"""
    morseCodeToCharDict = {}
    for char in charToMorseCodeDictionary:
        morseCodeToCharDict[charToMorseCodeDictionary[char]] =  char
    return morseCodeToCharDict


def encryptOrDecrypt():
    """asks for user input on what they would like to do and returns it
    as a string"""
    possibleChoices = ["e","d","x"]
    choice = input("Would you like to (e)ncrypt a file, (d)ecrypt a file, or e(x)it (enter e, d, or x)? ")
    while not choice in possibleChoices:
       choice = input("Sorry, that's an invalid choice. Please enter only e, d, or x: ")
    return choice
        


def encrypt(charToMorseCodeDictionary):
    """Asks user for the file they would like to encrypt and then passes that to
    hardEncryption if the new file name doesn't exist. If it does then it warns
    the user and asks if they're okay overwriting that file or if they want to
    create a new file"""
    fileName = input("Enter the text-file name to encrypt: ")
    while not exists(fileName):
        fileName = input("The text file" + fileName + "does not exit. Please enter a text-file name to encrypt: ")
    newFileName = fileName[:-4]+".zzz"
    if not exists(newFileName):
        hardEncryption(fileName,newFileName,charToMorseCodeDictionary)
            
    elif exists(newFileName):
        overWrite = input("WARNING: The file " + newFileName + " already exists!\n Is it okay to wipe it out (y/n)? ")
        while not overWrite == "n" and not overWrite == "y":
            overWrite = input("That is not a proper input. Please enter 'y' or 'n': ")
        if overWrite == "y":
            hardEncryption(fileName,newFileName,charToMorseCodeDictionary) 
        elif overWrite == "n":
            newFileName = input("please enter a new file name to use: ")+".zzz"
            hardEncryption(fileName,newFileName,charToMorseCodeDictionary)


    print("The file "+ fileName + " was succesfsfully encrypted to Morse-code and saved in the file " + newFileName)

def hardEncryption(fileName,newFileName,charToMorseCodeDictionary):
    """Reads through text file and creates a list of all the lines inside of it.
    Then it loops through each line and seperates by words, then by characters.
    Appends this morse code to a new string which is written to file at the very
    end"""
    newString = ""
    myFile = open(fileName,"r")
    newFile = open(newFileName,"w")
    lineList = myFile.readlines()
    for line in lineList:
        line = line.rstrip()
        line = line.split()
        for word in line:
            for char in word:
                char = char.upper()
                try:
                    newString += str(charToMorseCodeDictionary[char]) + "   "
                except:
                    pass
            newString += "       "
        newString += ".-.-   "
    newFile.write(newString)
    myFile.close()
    newFile.close()

        
def decrypt(morseCodeToCharDictionary):
    """Asks user for the file they would like to decrypt and then passes that to
    hardDecryption if the new file name doesn't exist. If it does then it warns
    the user and asks if they're okay overwriting that file or if they want to
    create a new file"""
    fileName = input("Enter the text-file name to decrypt: ")
    while not exists(fileName):
        fileName = input("The text file" + fileName + "does not exit. Please enter a text-file name to decrypt: ")
    newFileName = fileName[:-4]+".txt"
    if not exists(newFileName):
        hardDecryption(fileName,newFileName,morseCodeToCharDictionary)

    if not exists(newFileName):
        hardDecryption(fileName,newFileName,morseCodeToCharDictionary)
            
    elif exists(newFileName):
        overWrite = input("WARNING: The file " + newFileName + " already exists!\n Is it okay to wipe it out (y/n)? ")
        while not overWrite == "n" and not overWrite == "y":
            overWrite = input("That is not a proper input. Please enter 'y' or 'n': ")
        if overWrite == "y":
            hardDecryption(fileName,newFileName,morseCodeToCharDictionary) 
        elif overWrite == "n":
            newFileName = input("please enter a new file name to use: ")+".txt"
            hardDecryption(fileName,newFileName,morseCodeToCharDictionary)

    print("The file "+ fileName + " was succesfsfully decrypted to Morse-code and saved in the file " + newFileName)

def hardDecryption(fileName,newFileName,morseCodeToCharDictionary):
    """Reads through text file and creates a list of all the lines inside of it.
    Then it loops through each line and seperates by words, then by characters.
    Appends these characters to a new string which is written to file at the very
    end"""
    newString = ""
    myFile = open(fileName,"r")
    newFile = open(newFileName,"w")
    tempString = myFile.read()
    word = tempString.split("       ")
    for char in word:
        wordList = char.split("   ")
        for char in wordList:
            try:
                newString += str(morseCodeToCharDictionary[char])
            except:
                pass
        newString += " "
    newFile.write(newString)
    myFile.close()
    newFile.close()

while True:
    main()
    print()
