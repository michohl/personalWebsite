"""
File: sortingAlgorithims.py
Author: Michael Riesberg-Timmer
Description: modify bubble and merge sorts
"""

import random
from time import clock

def bubbleSort(myList):
    """Rearranges the items in myList so they are in ascending order"""
    for lastUnsortedIndex in range(len(myList)-1,0,-1):
        for testIndex in range(lastUnsortedIndex):
            if testIndex-1 >= 0:
                if myList[testIndex] < myList[testIndex-1]:
                    temp = myList[testIndex]
                    myList[testIndex] = myList[testIndex-1]
                    myList[testIndex-1] = temp
        for testIndex in range(lastUnsortedIndex):
            if myList[testIndex] > myList[testIndex+1]:
                temp = myList[testIndex]
                myList[testIndex] = myList[testIndex+1]
                myList[testIndex+1] = temp


def mergeSort(alist):
    if len(alist)>1:
        mid = len(alist)//2
        leftHalf = alist[:mid]
        rightHalf = alist[mid:]

        mid = len(leftHalf)//2

        leftLeftHalf = leftHalf[:mid]
        leftRightHalf = leftHalf[mid:]

        mid = len(leftHalf)//2

        rightRightHalf = rightHalf[mid:]
        rightLeftHalf = rightHalf[:mid]
       

        mergeSort(leftLeftHalf)
        mergeSort(rightLeftHalf)
        mergeSort(leftRightHalf)
        mergeSort(rightRightHalf)
        

        i=0
        j=0
        k=0
        while i<len(leftHalf) and j<len(rightHalf):
            if leftHalf[i]<rightHalf[j]:
                alist[k]=leftHalf[i]
                i=i+1
            else:
                alist[k]=rightHalf[j]
                j=j+1
            k=k+1

        while i<len(leftHalf):
            alist[k]=leftHalf[i]
            i=i+1
            k=k+1

        while j<len(rightHalf):
            alist[k]=rightHalf[j]
            j=j+1
            k=k+1
