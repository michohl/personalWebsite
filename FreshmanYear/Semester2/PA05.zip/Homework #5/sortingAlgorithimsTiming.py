"""
File: sortingAlgorithimsTiming.py
Author: Michael Riesberg-Timmer
Description: Time algorithims form sorthingAlgorithims.py
"""

from sortingAlgorithims import bubbleSort
from sortingAlgorithims import mergeSort
import random
from time import clock

def main():
    userInput = str(input("would you like to time [B]ubble or [M]erge: "))
    myList = []

    
    if userInput.upper() == "B":
        #Bubble descending
        print("adding items to list in descending order...")
        myList = list(range(10000,0,-1))
        print("Before sorting list:",end='')
        print(myList[0],myList[1],myList[2],". . .",myList[-3],myList[-2],myList[-1])
        print("Sorting items now, please wait...")
        start = clock()
        bubbleSort(myList)
        finish = clock()
        print("This sort took",finish-start," seconds\n")

        #Bubble ascending
        print("adding items to list in ascending order...")
        myList = list(range(0,10000))
        print("Before sorting list:",end='')
        print(myList[0],myList[1],myList[2],". . .",myList[-3],myList[-2],myList[-1])
        print("Sorting items now, please wait...")
        start = clock()
        bubbleSort(myList)
        finish = clock()
        print("This sort took",finish-start," seconds\n")
        
        #Bubble random (twice)
        for time in range(0,2):
            print("adding items to list in random order...")
            myList = list(range(0,10000))
            print("Before sorting list:",end='')
            print(myList[0],myList[1],myList[2],". . .",myList[-3],myList[-2],myList[-1])
            print("Sorting items now, please wait...")
            start = clock()
            bubbleSort(myList)
            finish = clock()
            print("This sort took",finish-start," seconds\n")

            
    elif userInput.upper() == "M":
        #Merge Random (100,000)
        print("adding 100,000 items to list")
        for item in range(0,100000):
            myList.append(random.randint(0,10000))
        print("Before sorting list:",end='')
        print(myList[0],myList[1],myList[2],". . .",myList[-3],myList[-2],myList[-1])
        print("Sorting items now, please wait...")
        start = clock()
        mergeSort(myList)
        finish = clock()
        print("This sort took",finish-start," seconds\n")

        #Merge Random (200,000)
        print("adding 200,000 items to list")
        for item in range(0,200000):
            myList.append(random.randint(0,10000))
        print("Before sorting list:",end='')
        print(myList[0],myList[1],myList[2],". . .",myList[-3],myList[-2],myList[-1])
        print("Sorting items now, please wait...")
        start = clock()
        mergeSort(myList)
        finish = clock()
        print("This sort took",finish-start," seconds\n")
        
        #Merge Random (400,000)
        print("adding 400,000 items to list")
        for item in range(0,400000):
            myList.append(random.randint(0,10000))
        print("Before sorting list:",end='')
        print(myList[0],myList[1],myList[2],". . .",myList[-3],myList[-2],myList[-1])
        print("Soting items now, please wait...")
        start = clock()
        mergeSort(myList)
        finish = clock()
        print("This sort took",finish-start," seconds\n")
main()
