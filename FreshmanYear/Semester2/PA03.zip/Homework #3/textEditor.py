"""
File: cursorBasedListTester.py

Menu-driven tester for Cursor-Based List implementation
"""

from cursor_based_list import CursorBasedList
from os.path import exists

def main():
    myList = CursorBasedList()
    createOrEdit = str(input("Enter 'E' to edit or 'C' to create a new file: "))
    if createOrEdit.upper() == "E":
        fileName = str(input("Enter a file to edit: "))
        if not exists(fileName):
            fileName = input("The text file" + fileName + "does not exit. Please enter a text-file name to encrypt: ")
        newFileName = fileName[:-4]+".txt"
        newFileName = fileName[:-4]+".txt"
        myFile = open(newFileName,"r")
        for line in myFile:
            myList.insertAfter(line)
        myFile = open(newFileName,"w")
    elif createOrEdit.upper() == "C":
        fileName = str(input("Enter a file to create: "))
        if exists(fileName):
            overWrite = input("WARNING: The file " + fileName + " already exists!\n Is it okay to wipe it out (y/n)? ")
            while not overWrite == "n" and not overWrite == "y":
                overWrite = input("That is not a proper input. Please enter 'y' or 'n': ")
            if overWrite == "y":
                myFile = open(fileName,"w")
            elif overWrite == "n":
                fileName = input("please enter a new file name to use: ")+".txt"
                myFile = open(fileName,"w")
        myFile = open(fileName,"w")
                      
   
    while True:
        print("\n===============================================================")
        print("Current List:",myList)
        if myList.isEmpty():
            print("Empty list")
        else:
            print("length:",len(myList), " Current item:", myList.getCurrent())
        print("\nTest Positional List Menu:")
        print("A - insertAfter")
        print("B - insertBefore")
        print("C - getCurrent")
        print("E - isEmpty")
        print("F - First")
        print("L - Last")
        print("N - Next")
        print("P - Previous")
        print("R - remove")
        print("U - replace")
        print("X - eXit testing")
        response = input("Menu Choice? ").upper()
        if response == 'A':
            item = input("Enter the new item to insertAfter: ")
            myList.insertAfter(item+"\n")
        elif response == 'B':
            item = input("Enter the new item to insertBefore: ")
            myList.insertBefore(item+"\n")
        elif response == 'C':
            item = myList.getCurrent()
            print("The current item in the list is:",item)
        elif response == 'E':
            print("isEmpty returned:", myList.isEmpty())
        elif response == 'F':
            myList.first()
        elif response == 'L':
            myList.last()
        elif response == 'N':
            myList.next()
            if myList.getCurrent() == None:
                print("This is the last line.")
                myList.previous()        
        elif response == 'P':
            myList.previous()
            if myList.getCurrent() == None:
                print("This is the first line.")
                myList.next()
        elif response == 'R':
            item = myList.remove()
            print("item removed:",item)
        elif response == 'U':
            item = input("Enter replacement item: ")
            myList.replace(item+"\n")
        elif response == 'X':
            temp = myList
            temp.first()
            for node in range(0,len(temp)):
                item = temp.getCurrent()
                item = str(item)
                print(item)
                myFile.write(item)
                temp.next()
            myFile.close()
            break
        else:
            print("Invalid Menu Choice!")
        

main()
