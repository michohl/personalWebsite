"""
File: wordAndConcordance.py
Author: Michael Riesberg-Timmer
Description: generate a word concordance with line numbers for each main word
"""
from chaining_dictionary import ChainingDict
from avl_tree import AVLTree
from open_addr_hash_dictionary import OpenAddrHashDict
from binary_search_tree import BinarySearchTree
import sys
from time import clock
sys.setrecursionlimit(10000)

ALPHABET = "abcdefghijklmnopqrstuvwxyz"
NUMBERS = "1234567890"

def main(stopWordsFile,fileToProcess):
    userInput = str(input("[L]inear,[Q]uadratic,[A]vl,[B]st,[C]haining: "))
    startTime = clock()

    #create empty dictionaries based on user input
    CAP = 32768
    if userInput.upper() == "L":
        wordConcordanceDict = OpenAddrHashDict(capacity=CAP)
        stopWordsDict = OpenAddrHashDict(capacity=CAP)
    elif userInput.upper() == "Q":
        wordConcordanceDict = OpenAddrHashDict(linear=False,capacity=CAP)
        stopWordsDict = OpenAddrHashDict(linear=False,capacity=CAP)
    elif userInput.upper() == "A":
        wordConcordanceDict = AVLTree()
        stopWordsDict = AVLTree()
    elif userInput.upper() == "B":
        wordConcordanceDict = BinarySearchTree()
        stopWordsDict = BinarySearchTree()
    elif userInput.upper() == "C":
        wordConcordanceDict = ChainingDict(capacity=CAP)
        stopWordsDict = ChainingDict(capacity=CAP)

    #add stop words to stop word dictionary
    myFile = open(stopWordsFile,"r")
    for word in myFile:
        word = word.strip()
        stopWordsDict[word]=None

    
    badCharacters = ',().-!:;\?*"'
    myFile = open(fileToProcess,"r")
    lineCounter = 1
    for line in myFile:
        line = line.strip()
        
        line = line.split()
        for word in line:
            word = word.lower()
            wordList = list(word)
            for symbol in badCharacters:
                while symbol in word:
                    if "," in word:
                        word = word.replace(",",'')
                    if "(" in word:
                        word = word.replace("(",'')
                    if ")" in word:
                        word = word.replace(")",'')
                    if "." in word:
                        word = word.replace(".",'')
                    if "-" in word:
                        word = word.replace("-",'')
                    if "!" in word:
                        word = word.replace("!",'')
                    if ":" in word:
                        word = word.replace(":",'')
                    if ";" in word:
                        word = word.replace(";",'')
                    if "\"" in word:
                        word = word.replace(",",'')
                    if "?" in word:
                        word = word.replace("?",'')
                    if "*" in word:
                        word = word.replace("*",'')
                    if '"' in word:
                        word = word.replace('"','')
            if word == '':
                break
            if not word[0] in ALPHABET:
                break
            if not word in stopWordsDict:
                try:
                    wordConcordanceDict[word].append(lineCounter)
                except:
                    wordConcordanceDict[word]=list()
                    wordConcordanceDict[word].append(lineCounter)
        lineCounter += 1
    stopTime = clock()
    print("This dictionary type took ",stopTime-startTime," seconds to work.")

    """If you want to see the final dictionary uncomment the next line"""
    #printingDictionary(wordConcordanceDict,startTime,stopTime)


def printingDictionary(wordConcordanceDict,startTime,stopTime):
    wordList = list()
    for item in wordConcordanceDict:
        wordList.append(item)
    wordList.sort()
    for word in wordList:
        print(str(word)+":",end=' ')
        for lineNumber in wordConcordanceDict[word]:
            print(lineNumber,end=' ')
        print()
    print("This dictionary type took ",stopTime-startTime," seconds to work.")
    
    
main("stop_words.txt","WarAndPeace.txt")
