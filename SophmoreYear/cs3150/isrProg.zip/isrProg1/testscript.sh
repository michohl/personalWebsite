#!/bin/bash

candidates=$(ls isr* | grep -v cpp$ | grep -v java$ | grep -v cs$ | wc -l)
if [ $candidates -eq 1 ] ;
then
    prog=$(ls isr* | grep -v cpp$ | grep -v java$ | grep -v cs$ )
else
    echo Ambiguous program name.
    exit
fi

if [[ "${prog/%class/}" != "${prog}" ]]
then
    echo Found class file $prog
    cmd="java ${prog/\.class/}"
else
    echo Dealing with raw $prog
    cmd="./$prog"
fi

# Test no arguments
filename="prog1-test1.out"
echo "Test 1: No arguments" > $filename
echo "This should result in a usage statement" >> $filename
echo "command \"$cmd\"" >> $filename
$cmd >> $filename 2>&1

filename="prog1-test2.out"
echo "Test 2: Invalid file specified (single) " > $filename
echo "This should result in a usage statement" >> $filename
echo "\"$cmd /tmp/doesnotexist\"" >> $filename
$cmd /tmp/doesnotexist >> $filename 2>&1

filename="prog1-test3.out"
echo "Test 3: Invalid file specified (later in the arguments list) " > $filename
echo 'This should result in *NO* parsing and a usage statement' >> $filename
echo "\"$cmd ~/letters/* /tmp/doesnotexist\"" >> $filename
timeout 10s $cmd ~/letters/* /tmp/doesnotexist >> $filename 2>&1

filename="prog1-test4.out"
echo "Test 4: Valid list of trivial words " > $filename
echo 'This should result in the alphabet' >> $filename
echo "\"$cmd ~/letters/*\"" >> $filename
timeout 30s $cmd ~/letters/* >> $filename 2>&1

filename="prog1-test5.out"
echo "Test 5: Valid list of Shakespeare comedies " > $filename
echo 'This should result in a modest wordlist' >> $filename
echo "\"$cmd ~/Shakespeare/comedies/*\"" >> $filename
$cmd ~/Shakespeare/comedies/* >> $filename 2>&1 &

filename="prog1-test6.out"
echo "Test 6: Valid list of all Shakespeare " > $filename
echo 'This should result in a full wordlist' >> $filename
echo "\"$cmd ~/Shakespeare/*/*\"" >> $filename
var=$(time ($cmd ~/Shakespeare/*/*  >> $filename) 2>&1)
echo '---' >> $filename
echo $var >> $filename
