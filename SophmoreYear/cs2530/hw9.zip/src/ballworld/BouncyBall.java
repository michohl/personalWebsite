package ballworld;
import javax.swing.JFrame;

public class BouncyBall extends BoundedBall {
	
	//
	//instance variables
	//
	private int maxSpeed = 50;
	private int minSpeed = 1;
	private int speedDirection = 1;
	
	//
	//Constructors
	//
	/**
	 * Constructor to create a BouncyBall within a JFrame.
	 * 
	 * @param x The initial x coordinate of the BouncyBall.
	 * @param y The initial y coordinate of the BouncyBall.
	 * @param r The initial radius of the Ball.
	 * @param dx The delta in the x coordinate for moving. 
	 * @param dy The delta in the y coordinate for moving.
	 * @param aFrame The JFrame the ball will be bound by.
	 */
	public BouncyBall(int x, int y, int r, int dx, int dy, JFrame aFrame) {
		super(x, y, r, dx, dy, aFrame);
		
				
	}
	
	//
	//methods
	//
	
	@Override
	public void move()
	{
		super.move();
		if(deltaX>0){
			if(deltaX < maxSpeed && speedDirection == 1){
				deltaX += 1;
				if(deltaX == maxSpeed){
					speedDirection = -1;
				}
			}
			if(deltaX > minSpeed && speedDirection == -1){
				deltaX -= 1;
				if(deltaX == minSpeed){
					speedDirection = 1;
				}
			}
		}
		
		if(deltaY>0){
			if(deltaY < maxSpeed && speedDirection == 1){
				deltaY += 1;
				if(deltaY == maxSpeed){
					speedDirection = -1;
				}
			}
			if(deltaY > minSpeed && speedDirection == -1){
				deltaY -= 1;
				if(deltaY == minSpeed){
					speedDirection = 1;
				}
			}
		}


		
		
	}
}


