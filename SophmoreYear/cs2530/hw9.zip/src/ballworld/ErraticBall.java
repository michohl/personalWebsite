package ballworld;

import javax.swing.JFrame;

public class ErraticBall extends BoundedBall {
	//
	//instance variables
	//
	private int direction = 1;
	
	//
	//Constructors
	//
	/**
	 * Constructor to create a ErraticBall within a JFrame.
	 * 
	 * @param x The initial x coordinate of the ErraticBall.
	 * @param y The initial y coordinate of the ErraticBall.
	 * @param r The initial radius of the Ball.
	 * @param dx The delta in the x coordinate for moving. 
	 * @param dy The delta in the y coordinate for moving.
	 * @param aFrame The JFrame the ball will be bound by.
	 */
	public ErraticBall(int x, int y, int r, int dx, int dy, JFrame aFrame) {
		super(x, y, r, dx, dy, aFrame);
	}
	
	//
	//Methods
	//
	
	@Override
	public void move(){
		super.move();
		
		if(direction == 1){
			this.reverseDeltaY();
			this.reverseDeltaX();
		}
	direction =	(int) Math.floor(Math.random()*50);
	}
}
