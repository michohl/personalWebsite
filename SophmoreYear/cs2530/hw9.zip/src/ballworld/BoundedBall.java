package ballworld;
import java.awt.Color;

import javax.swing.JFrame;



public class BoundedBall extends Ball 
{

	//-----------------------------------------
	// Instance Variables
	//-----------------------------------------
	private JFrame myWorld;
	
	
	//-----------------------------------------
	// Constructors
	//-----------------------------------------
	/**
	 * Constructor to create a BoundedBall within a JFrame.
	 * 
	 * @param x The initial x coordinate of the BoundedBall.
	 * @param y The initial y coordinate of the BoundedBall.
	 * @param r The initial radius of the Ball.
	 * @param dx The delta in the x coordinate for moving. 
	 * @param dy The delta in the y coordinate for moving.
	 * @param aFrame The JFrame the ball will be bound by.
	 */
	public BoundedBall(int x, int y, int r, int dx, int dy, JFrame aFrame) 
	{
		super(x, y, r, dx, dy);
		this.setColor(Color.yellow);
		myWorld = aFrame;
	}

	//-----------------------------------------
	// Class Methods
	//-----------------------------------------
	
	/**
	 * Moves the BoundedBall based on the deltaX and deltaY values.
	 * If it encounters the edge of the JFrame, it reverses direction.
	 */
	@Override
	public void move()
	{
		super.move();
		
		int maxWidth = myWorld.getWidth();
		if (( this.getX() < 0) || ( this.getX() > maxWidth))
			reverseDeltaX();
			
		int maxHeight = myWorld.getHeight();
		if (( this.getY() < 0) || ( this.getY() > maxHeight))
			reverseDeltaY();
	}

	//-----------------------------------------
	// Helper Methods
	//-----------------------------------------
	
    protected void reverseDeltaX()
    {
    	deltaX *= -1;
    }
    
    protected void reverseDeltaY()
    {
    	deltaY *= -1;
    }
}

