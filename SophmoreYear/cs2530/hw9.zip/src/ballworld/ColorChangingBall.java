package ballworld;

import java.awt.Color;

import javax.swing.JFrame;

public class ColorChangingBall extends BoundedBall {
	//
	//instance variables
	//
	private int colorNum;
	
	//
	//Constructors
	//
	
	/**
	 * Constructor to create a ColorChangingBall within a JFrame.
	 * 
	 * @param x The initial x coordinate of the ColorChangingBall.
	 * @param y The initial y coordinate of the ColorChangingBall.
	 * @param r The initial radius of the Ball.
	 * @param dx The delta in the x coordinate for moving. 
	 * @param dy The delta in the y coordinate for moving.
	 * @param aFrame The JFrame the ball will be bound by.
	 */
	public ColorChangingBall(int x, int y, int r, int dx, int dy, JFrame aFrame) {
		super(x, y, r, dx, dy, aFrame);
	}
	
	//
	//methods
	//
	
	/**
	 * Generates a random color and assigns it to the ball.
	 */
	private void randomColor(){
		colorNum = (int) Math.floor(Math.random()*3);
		if(colorNum == 0){
			this.setColor(Color.red);
		}
		if(colorNum == 1){
			this.setColor(Color.green);
		}
		if(colorNum == 2){
			this.setColor(Color.blue);
		}
	}
	
	/**
	 * reverses the deltaX and assigns a new random color to it.
	 */
	protected void reverseDeltaX()
    {
		randomColor();
    	deltaX *= -1;
    }
    
	/**
	 * reverses the deltaY and assigns a new random color to it.
	 */
    protected void reverseDeltaY()
    {
    	randomColor();
    	deltaY *= -1;
    }

}
