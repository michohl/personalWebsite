package ballworld;

public class AcceleratingBall extends Ball {
	//
	//Instance variables
	//
	private int maxSpeed = 50;
	//
	//Constructors
	//
	/**
	 * Constructor to create a AcceleratingBall within a JFrame.
	 * 
	 * @param x The initial x coordinate of the AcceleratingBall.
	 * @param y The initial y coordinate of the AcceleratingBall.
	 * @param r The initial radius of the Ball.
	 * @param dx The delta in the x coordinate for moving. 
	 * @param dy The delta in the y coordinate for moving.
	 */
	public AcceleratingBall(int x, int y, int r, int dx, int dy) {
		super(x, y, r, dx, dy);
	}

	//
	//Class Methods
	//
	
	@Override
    public void move()
    {
    	super.move();
    	if(deltaX > 0){
    		if(deltaX < maxSpeed){
    			deltaX += 1;
    		}
    	if(deltaY > 0){
    		if(deltaY < maxSpeed){
    			deltaY += 1;
    		}
    	}
    	}

        moveBy( deltaX, deltaY );
    }
    
}
