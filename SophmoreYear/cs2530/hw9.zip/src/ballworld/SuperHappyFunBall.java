package ballworld;

import java.awt.Color;

import javax.swing.JFrame;

public class SuperHappyFunBall extends BouncyBall {
	//
	//instance variables
	//
	private int colorNum;
	
	//
	//constructors
	//
	/**
	 * Constructor to create a SuperHappyFunBall within a JFrame.
	 * 
	 * @param x The initial x coordinate of the SuperHappyFunBall.
	 * @param y The initial y coordinate of the SuperHappyFunBall.
	 * @param r The initial radius of the Ball.
	 * @param dx The delta in the x coordinate for moving. 
	 * @param dy The delta in the y coordinate for moving.
	 * @param aFrame The JFrame the ball will be bound by.
	 */
	public SuperHappyFunBall(int x, int y, int r, int dx, int dy, JFrame aFrame) {
		super(x, y, r, dx, dy, aFrame);
	}
	
	//
	//methods
	//
	
	/**
	 * Generates a random color and assigns it to the ball.
	 */
	private void randomColor(){
		colorNum = (int) Math.floor(Math.random()*3);
		if(colorNum == 0){
			this.setColor(Color.red);
		}
		if(colorNum == 1){
			this.setColor(Color.green);
		}
		if(colorNum == 2){
			this.setColor(Color.blue);
		}
	}
	
	@Override
	public void move(){
		super.move();
		randomColor();
		
		
	}
}
