package ballworld;


import java.awt.Color;
import java.awt.Graphics;

/**
 *  Disk is a base class that draws circles.
 *  
* Note: Adapted from Ball class by Tim Budd in the textbook
*       Understanding Object-Oriented Programming with Java
* 
* @author Michael J. Holmes
* @version 2.0 2/20/2015 
* 
*  added setColor method.
*
*/

public class Disk
{
  //----------------------------------------------
  //  Instance Variables
  //----------------------------------------------
  private int   x;
  private int   y;
  private int   radius;
  private Color color;

  
  //----------------------------------------------
  //  Constructors
  //----------------------------------------------  
  
  /**
   * Constructor to create a disk at the x,y coordinates with a given radius. 
   * 
   * @param x The initial x coordinate of the disk.
   * @param y The initial y coordinate of the disk.
   * @param r The initial radius of the disk.
   */
  public Disk( int x, int y, int r )
  {
    this.x = x;
    this.y = y;
    radius = r;
    color  = Color.blue;
  }
  
  /**
   * Constructor to create a disk with a specific color.
   * 
   * @param x The initial x coordinate of the disk.
   * @param y The initial y coordinate of the disk.
   * @param r The initial radius of the disk.
   * @param myColor The initial color of the disk.
   */
  public Disk( int x, int y, int r, Color myColor )
  {
    this.x = x;
    this.y = y;
    radius = r;
    color  = myColor;
  }
  
  
	//-----------------------------------------
	// Class Methods
	//-----------------------------------------

  /**
   * Paints the disk onto the frame.
   * 
   * @param g The graphics environment variables.
   */
  public void paint( Graphics g )
  {
    g.setColor( color );
    g.fillOval( x, y, radius*2, radius*2 );
  }
  
  
  //-----------------------------------------
  // Helper Methods
  //-----------------------------------------
  
  /**
   * Moves the x and y coordinates by the deltaX and deltaY values.
   * 
   * @param deltaX The delta for the x coordinate.
   * @param deltaY The delta for the y coordinate.
   */
  protected void moveBy( int deltaX, int deltaY )
  {
    x += deltaX;
    y += deltaY;
  }
  
  /**
   * Returns the current position on the x coordinate.
   * 
   * @return - the current position on the x coordinate.
   */
  protected int getX()
  {
	  return x;
  }
  
  /**
   * Returns the current position on the y coordinate.
   * 
   * @return - the current position on the y coordinate.
   */  
  protected int getY()
  {
	  return y;
  }
  
  /**
   * Allows subclasses to get the color of the disk.
   * 
   * @return the current color of the disk.
   */
  protected Color getColor()
  {
	return color;  
  }
  
  /**
   * Allows the class or subclasses to change the color after creation.
   * 
   * @param newColor the color to change the ball to. 
   */
  protected void setColor(java.awt.Color newColor)
  {
	  color = newColor;
  }
}
