package presentation;
import java.awt.*;
import java.util.ArrayList;

import javax.swing.*;

import ballworld.*;

/**
 *  MultiBallWorldFrame is a frame that contains  multiple balls.
 *
* Note: Adapted from Ball class by Tim Budd in the textbook
*       Understanding Object-Oriented Programming with Java
*
* @author Michael J. Holmes
* @version 2.0 2/20/2015
* 
* Added the ability to add new ball objects to the world after it is created.
*
*/

public class MultiBallWorldFrame extends JFrame
{
	  private static final int FRAME_WIDTH  = 600;
	  private static final int FRAME_HEIGHT = 400;
	
	
  //---------------------------------------------------------
  // Instance Variables
  //---------------------------------------------------------
  protected ArrayList<Ball> ballArray;


  //---------------------------------------------------------
  // Constructors
  //---------------------------------------------------------
  /**
   * Default constructor creates the frame and places a ball
   * inside of it.
   */
  public MultiBallWorldFrame()
  {
    this(1);
  }

   /**
   * Default constructor creates the frame and places a ball
   * inside of it.
   */
  public MultiBallWorldFrame(int numberOfBalls)
  {
	  super();

	  setSize (FRAME_WIDTH, FRAME_HEIGHT);
	  setTitle("Multi Ball World");

	  //Use the original ball and an array for the rest.
      ballArray = new ArrayList<Ball>();
      for (int i = 0; i < numberOfBalls; i++)
      {    	  
    	  int myDx = (int) (5 * Math.random());
    	  int myDy = (int) (2 * Math.random());
    	  
          ballArray.add(new  Ball(  84-i*2, 84-i*2, 10, myDx, myDy));
      }
  
  }
  
  /**
   * Adds the ball into the ball frame.
   * 
   * @param aBall the Ball to add.
   */
  public void addBall(Ball aBall)
  {
	  ballArray.add(aBall);
  }
  
  /**
   * Paints the frame with the updated ball positions.
   */
  @Override
  public void paint( Graphics g )
  {
          super.validate();
	  super.paint(g);
	  
      for (int i = 0; i < ballArray.size(); i++)
      {
          ballArray.get(i).paint( g );
          ballArray.get(i).move();
      }

      try 
      {
  		Thread.sleep(30);
  	  } 
      catch (InterruptedException e) 
      {
  		e.printStackTrace();
  	  }
      

      repaint();

  }
  

  }

