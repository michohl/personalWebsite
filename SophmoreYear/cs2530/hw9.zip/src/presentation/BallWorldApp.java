package presentation;

import ballworld.AcceleratingBall;
import ballworld.BoundedBall;
import ballworld.BouncyBall;
import ballworld.ErraticBall;
import ballworld.SuperHappyFunBall;
import ballworld.ColorChangingBall;
 /**
 * Simple BallWorld Application.
 * 
 * Note: Adapted from Ball class by Tim Budd in the textbook
 *       Understanding Object-Oriented Programming with Java
 * 
 * @author Michael J. Holmes
 * @version 1.0 2/20/2013
 *
 */
public class BallWorldApp
{
  public static void main( String[] args )
  {
    MultiBallWorldFrame world = new MultiBallWorldFrame(0);
    
    //world.addBall(new BoundedBall(2,2,10,5,6,world));
    //world.addBall(new BoundedBall(2,2,10,6,6,world));
    //world.addBall(new BoundedBall(2,2,10,7,6,world));
    //world.addBall(new BoundedBall(2,2,10,20,6,world));
    //world.addBall(new BoundedBall(2,2,10,3,6,world));
    //world.addBall(new BoundedBall(2,2,10,3,10,world));
    
    world.addBall(new AcceleratingBall(2,2,10,1,1));
    world.addBall(new BouncyBall(2,2,10,1,1, world));
    world.addBall(new ErraticBall(100,100,10,4,5, world));
    world.addBall(new SuperHappyFunBall(2,2,10,1,1, world));
    world.addBall(new ColorChangingBall(2,2,10,4,4, world));
    
    world.setVisible( true );
  }
}










