//imports
import java.util.Scanner;

/**Description
*A robot attack application using a robot class
*
*@author Michael Riesberg-Timmer
*@Version 1.0  09/04/2016
*
*/

public class RobotAttackApp {
	public static void main(String[] args){
		System.out.println("Preparing robots for combat...");
		//Local variables
		Robot playerRobot;
		Robot computerRobot;
		String nextAttack = "";
		  Scanner consoleInput = new Scanner(System.in);
		
		//Instantiate robots
		playerRobot = new Robot();
		computerRobot = new Robot();
		
		while (true)
		{
			if (playerRobot.isDisabled() == true){
				System.out.print("You have been defeated by the computer...");
				break;
			}
			if (computerRobot.isDisabled() == true){
				System.out.print("You have defeated the computer!");
				break;
			}
			//prompt user
			System.out.print("Would you like to use a (L)aser attack, (R)ocket attack, or (P)ower up: ");
			nextAttack = consoleInput.next();
			
			//perform actions
			if (nextAttack.toLowerCase().equals("l")){
				boolean playerAttackLand = false;
				playerAttackLand = playerRobot.laserAttack(computerRobot);
				if (playerAttackLand == false){
					System.out.println("The player's attack has missed");
				}
				if (playerAttackLand == true){
					System.out.println("The player's attack has landed!");
				}
			}
			if (nextAttack.toLowerCase().equals("r")){
				boolean playerAttackLand = false;
				playerAttackLand = playerRobot.rocketAttack(computerRobot);
				if (playerAttackLand == false){
					System.out.println("The player's attack has missed");
				}
				if (playerAttackLand == true){
					System.out.println("The player's attack has landed!");
				}
			}
			
			if (nextAttack.toLowerCase().equals("p")){
				playerRobot.recharge();
				System.out.println("The player recharges");
			}
			
//			if (!(nextAttack.toLowerCase().equals("p") || !nextAttack.toLowerCase().equals("r") || !nextAttack.toLowerCase().equals("l"))){
//				break;
//			}
			
			//computer uses laserAttack
			boolean computerAttackLand = false;
			computerAttackLand = computerRobot.laserAttack(playerRobot);
			if (computerAttackLand == false){
				System.out.println("The computer's attack has missed!");
			}
			if (computerAttackLand == true){
				System.out.println("The computer's attack has landed");
			};
			
			//display health
			double playerCurrentPower = 0;
			double computerCurrentPower = 0;
			playerCurrentPower = playerRobot.getCurrentPowerLevel();
			computerCurrentPower = computerRobot.getCurrentPowerLevel();
			System.out.println("Player's robot is at " + playerCurrentPower +"%");
			System.out.println("Computer's robot is at " + computerCurrentPower +"%");
			System.out.println("  ");
			
		}
	}
}