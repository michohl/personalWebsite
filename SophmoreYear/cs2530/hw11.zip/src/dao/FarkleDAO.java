package dao;

import java.io.IOException;
import gamecomponents.FarkleGame;

/**
 * Interface for any DAO to store and load FarkleGames.
 * 
 * @author Michael J. Holmes
 * @version 1.0   10-20-2016
 *
 */
public interface FarkleDAO {
	
	/**
	 * Loads a saved Farkle game from the inputed file path.
	 * 
	 * @param FilePath the full path to the file to load from.
	 * @return a FarkleGame created in the state the game was saved.
	 * @throws IOException
	 */
	public FarkleGame loadGame(String FilePath) throws IOException;
	
	
	/**
	 * Saves the current state of the Farkle game to the inputed file path.
	 * 
	 * @param gameToSave the FarkeGame object to save.
	 * @param FilePath the full path of where to save the game.
	 * @throws IOException
	 */
	public void saveGame(FarkleGame gameToSave, String FilePath) throws IOException;
	

}
