package dao;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Scanner;

import gamecomponents.FarkleDie;
import gamecomponents.FarkleGame;
import gamecomponents.FarkleScorer;
import gamecomponents.Player;
import gamecomponents.StandardFarkleScorer;

public class NonFunctionalFarkleDAO implements FarkleDAO {

	@Override
	public FarkleGame loadGame(String FilePath) throws IOException {
		ArrayList<Player> players;
		ArrayList<FarkleDie> dice;
		Scanner fileIn;
		String line;
		String[] initialValues;
		String[] savedValues;
		String[] scoredValues;
		String[] values;
		String fileName = null;
		FarkleScorer scorer;

		

		
		try
		{
			
		   // Open File	
		   fileIn = new Scanner(new FileInputStream(FilePath));
		   
				
		  //initialize sutff
		  line = fileIn.nextLine();

		   
		   //process first line
		   initialValues = line.split(",");

		   line = fileIn.nextLine();
		   
		   //process second line
		   savedValues = line.split(",");

			   line = fileIn.nextLine();
		   
		   //process third line
			   scoredValues = line.split(",");

				   line = fileIn.nextLine();
		   //create dice for array list
		   ArrayList<FarkleDie> myDice = new ArrayList<FarkleDie>();
		   for(int i=0;i<6;i++){
			   int initialValue = Integer.valueOf(initialValues[i]);
			   boolean savedValue = Boolean.valueOf(savedValues[i]);
			   boolean scoredValue = Boolean.valueOf(scoredValues[i]);
			   FarkleDie newDie = new FarkleDie(initialValue,savedValue,scoredValue);
			   myDice.add(newDie);
		   }   
			   
		   //process point goal
		   int ptsGoal = Integer.valueOf(line);
		   line = fileIn.nextLine();
		   
		   //processes currentPlayer, currentTurnScore (line 5 of file)
		   values = line.split(",");
		   int currentPlayer = Integer.valueOf(values[0]);
		   int currentTurnScore = Integer.valueOf(values[1]); 
		   line = fileIn.nextLine();
		   
		   
		   //process lastRound and outPlayer
		   values = line.split(",");
		   boolean lastRound = Boolean.valueOf(values[0]);
		   int outPlayer = Integer.valueOf(values[1]); 
		   line = fileIn.nextLine();		   

		   
		   //process each player and their score
		   ArrayList<Player> myPlayers = new ArrayList<Player>();
		   while ( fileIn.hasNext())
		   {
				line = fileIn.nextLine();
				
				values = line.split(",");
				String playerName = values[0];
				int playerPoints = Integer.valueOf(values[1]);
				Player newPlayer = new Player(playerName);
				newPlayer.addToScore(playerPoints);
				myPlayers.add(newPlayer);
				
				
		   }		
		   
		   
		   
		   
		   //create game
		   FarkleScorer myScorer = new StandardFarkleScorer();
		   FarkleGame myGame = new FarkleGame(myPlayers, myScorer, myDice, ptsGoal,currentPlayer, lastRound, outPlayer, currentTurnScore);
		   
  
		   
		   //return game
		   
		   return myGame;

		   

		}
		catch (IOException e)
		{
			throw e;
		}
		//return myGame;
		

		

		
		
	
	}

	@Override
	public void saveGame(FarkleGame gameToSave, String FilePath) throws IOException {
		//open fileOut
		File fout = new File(FilePath);
		FileOutputStream fos = new FileOutputStream(fout);
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		
		//loop through each initialValue and store to line 0
		ArrayList<FarkleDie> diceList = gameToSave.getDice();
		for (int i = 0; i < diceList.size(); i++) {
			FarkleDie diceString = diceList.get(i);
			String diceString1 = String.valueOf(diceString);
			String[] diceValues = diceString1.split("-");
			bw.write(diceValues[0] + ",");
			
		}	
		bw.newLine();
		//loop through each dieSaved and write to line 1
		ArrayList<FarkleDie> diceList1 = gameToSave.getDice();
		for (int i = 0; i < diceList1.size(); i++) {
			FarkleDie diceString = diceList.get(i);
			String diceString1 = String.valueOf(diceString);
			String[] diceValues = diceString1.split("-");
			bw.write(diceValues[1] + ",");
			
		}	
		bw.newLine();
		//loop through each dieScored and write to line 2
		ArrayList<FarkleDie> diceList11 = gameToSave.getDice();
		for (int i = 0; i < diceList11.size(); i++) {
			FarkleDie diceString = diceList.get(i);
			String diceString1 = String.valueOf(diceString);
			String[] diceValues = diceString1.split("-");
			bw.write(diceValues[0] + ",");
			
		}	
		bw.newLine();
		
		//write pointGoal to line 3
		bw.write(gameToSave.getPointGoal());
		bw.newLine();
		
		//write currentPlayer, currentTurnScore to line 4
		bw.write(gameToSave.getCurrentPlayer() + "," + gameToSave.getCurrentTurnScore());
		bw.newLine();
		
		//write lastROund, outPlayer to line 5
		bw.write(gameToSave.lastRound() + "," + gameToSave.getPlayerGoingOut());
		bw.newLine();
		
		//loop through players list and write each playerName and score on their own line
		ArrayList<Player> playersList = gameToSave.getPlayers(); 
		for (int i = 0; i < playersList.size(); i++) {
			Player playerName = playersList.get(i);
			String playerName1 = String.valueOf(playerName);
			int playerScore = playerName.getCurrentScore();
			bw.write(playerName1 + "," + playerScore);
			bw.newLine();
		}		
		

		 
			bw.close();	
		
		
		throw new IOException();

	}

}
