package gamecomponents;
/**
 * A StandardFarkleScoringRule allows for scoring a die value for a single die or a set of three
 * die with the same value.
 * 
 * It provides a point total back when given an array of int values representing the counts of
 * die values between 1 and 6.
 * 
 * @author Michael J. Holmes
 * @version  1.0  April 16, 2016
 *
 */
public class StandardFarkleScoringRule 
{
	//----------------------------------------
	// Instance Variables
	//----------------------------------------
	private int scoringValue;
	private int pointsForOne;
	private int pointsForThree;
	
	
	//----------------------------------------
	// Constructors
	//----------------------------------------
	/**
	 * Constructs a Standard Farkle Scoring rule for a die value and the points awarded for 
	 * a single die or three of a kind.
	 * 
	 * @param dieValue the die value that will be counted.
	 * @param pointsForOne the points awarded for a single die of that value.
	 * @param pointsForThree the points awarded for three of a kind of that value.
	 */
	public StandardFarkleScoringRule(int dieValue, int pointsForOne, int pointsForThree)
	{
		this.scoringValue = dieValue;
		this.pointsForOne = pointsForOne;
		this.pointsForThree = pointsForThree;
	}
	
	
	/**
	 * Calculates the points awarded based on the rule for a set of die values provided in an array.
	 * 
	 * @param dieValueCounts the array holding the number of 1s, 2s, 3s, 4s, 5s, and 6s rolled.
	 * @return the points scored based on the rule for the counts of die values.
	 * @throws InvalidFarkleScoreException if the value is not scorable
	 */
	public int getScore(int[] dieValueCounts) throws InvalidFarkleScoreException
	{
		if( (pointsForOne == 0) && (dieValueCounts[scoringValue-1] != 3) 
			&& (dieValueCounts[scoringValue-1] != 6) && (dieValueCounts[scoringValue-1] !=0))
		{
			throw new InvalidFarkleScoreException();
		}
		
		switch (dieValueCounts[scoringValue-1])
		{
			case 0: return 0;
			case 1: return pointsForOne;
			case 2: return pointsForOne * 2;
			case 3: return pointsForThree;
			case 4: return pointsForThree + pointsForOne;
			case 5: return pointsForThree + (pointsForOne * 2);
			case 6: return pointsForThree * 2;
			default: throw new InvalidFarkleScoreException();
		}
	}
	
	/**
	 * Determines if the die values rolled is a non-scoring or farkled situation for this rule.
	 * 
	 * @param dieValueCounts the array holding the number of 1s, 2s, 3s, 4s, 5s, and 6s rolled.
	 * @return true if the values passed in would not score for this rule.
	 */
	public boolean farkled(int[] dieValueCounts){
		if (pointsForOne > 0){
			return (dieValueCounts[scoringValue-1] == 0);
		}
		else{
		    return (dieValueCounts[scoringValue-1] < 3);
		}
	}
}
