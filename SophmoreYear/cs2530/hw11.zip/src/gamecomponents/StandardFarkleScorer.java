package gamecomponents;

import java.util.ArrayList;

/**
 * The StandardScorer implements that standard scoring rules for Farkle:
 * 		1 = 100
 *      1,1,1 = 1000
 *      2,2,2 = 200
 *      3,3,3 = 300
 *      4,4,4 = 400
 *      5     = 50
 *      5,5,5 = 500
 *      6,6,6 = 600
 *      
 * @author Michael J. Holmes
 * @version 1.0  April 16, 2016
 *
 */
public class StandardFarkleScorer implements FarkleScorer {

	//--------------------------------
	// Instance Variable
	//--------------------------------
	private int[] counts;  //Keeps track of the counts of 1s, 2s, 3s, 4s, 5s, 6s
	private ArrayList<StandardFarkleScoringRule> rules;
	
	
	//--------------------------------
	// Constructors
	//--------------------------------
	/**
	 * Constructs the Farkle scorer with the standard scoring rules.
	 */
	public StandardFarkleScorer()
	{
		counts = new int[6];
		
		rules = new ArrayList<StandardFarkleScoringRule>();
		rules.add(new StandardFarkleScoringRule(1,100,1000));
		rules.add(new StandardFarkleScoringRule(2,0,200));
		rules.add(new StandardFarkleScoringRule(3,0,300));
		rules.add(new StandardFarkleScoringRule(4,0,400));
		rules.add(new StandardFarkleScoringRule(5,50,500));
		rules.add(new StandardFarkleScoringRule(6,0,600));
	}
	
	
	//--------------------------------
	// Class Methods
	//--------------------------------
	@Override
	public boolean farkled(ArrayList<FarkleDie> diceToCheck){
		countDice(diceToCheck);

		for(StandardFarkleScoringRule aRule : rules){
			if(!aRule.farkled(counts)){
				return false;
			}
		}
		
		return true;
	}
	
	
	@Override
	public int scoreDice(ArrayList<FarkleDie> diceToScore) throws InvalidFarkleScoreException 
	{
		if (farkled(diceToScore))
		{
			throw new InvalidFarkleScoreException();
		}
	
		countDice(diceToScore);
		int score = 0;
		
		for(StandardFarkleScoringRule aRule : rules){
			score += aRule.getScore(counts);
		}
			
		return score;
	}
	
	
	
	
	
	//---------------------------------
	// Private Helper Methods
	//---------------------------------
	/**
	 * Counts the number of 1s, 2s, 3s, 4s, 5s, 6s on the dice to score and stores them
	 * in the counts array.
	 * 
	 * @param diceToScore the Farkle Dice that will be counted.
	 */
	private void countDice(ArrayList<FarkleDie> diceToScore)
	{
		resetCounts();
		
		for(FarkleDie aDie : diceToScore)
		{
			counts[aDie.getCurrentValue()-1]++;
		}
	}
	
	
	/**
	 * Resets all of the 1s, 2s, 3s, 4s, 5s, and 6s counts to 0.
	 */
	private void resetCounts()
	{
		for(int i = 0; i<6; i++)
			counts[i]=0;
	}
}
