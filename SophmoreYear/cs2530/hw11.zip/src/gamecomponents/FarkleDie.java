package gamecomponents;

/**
 * FarkleDie is a specialized die that can be flagged to be saved and scored.
 * If it is saved or scored it will keep its value when rolled.
 * 
 * @author Michael J. Holmes
 * @version 1.0	 April 16, 2016
 *
 */
public class FarkleDie extends Die {

	//---------------------------------
	// Instance Variables
	//---------------------------------
	private boolean saved;
	private boolean scored;
	
	
	//---------------------------------
	// Constructors
	//---------------------------------
	/**
	 * Constructs a standard 6-sided FarkleDie.
	 */
	public FarkleDie(){
		super();
		saved = false;
		scored = false;
	}
	
	/**
	 * Constructs a standard 6-sided FarkleDie, with the
	 * saved and scored flags initialized by parameter.
	 * 
	 * @param saved is the die currently being saved.
	 * @param scored has the die been scored.
	 */
	public FarkleDie(int initialValue, boolean saved, boolean scored){
		super();
		setCurrentValue(initialValue);
		this.saved = saved;
		this.scored = scored;
	}
	
	//---------------------------------
	// Class Methods
	//---------------------------------
	/**
	 * Returns if the die is saved or not.
	 * @return true if the die is saved, false otherwise.
	 */
	public boolean isSaved(){
		return saved;
	}
	
	/**
	 * Set's the die's saved value.
	 * 
	 * @param newValue true or false if it should be updated to be saved.
	 */
	public void setSave(boolean newValue)
	{
		saved = newValue;
	}
	
	/**
	 * Flips the die's saved value to the opposite of the current value.
	 */
	public void flipSave()
	{
		saved = !saved;
	}
	
	/**
	 * Returns if the die is scored or not.
	 * @return true if the die is scored, false otherwise.
	 */
	public boolean isScored()
	{
		return scored;
	}
	
	/**
	 * Sets the die's scored value.
	 * 
	 * @param newValue True or False if the die is scored.
	 */
	public void setScored(boolean newValue)
	{
		scored = newValue;
	}
	
	/**
	 * Resets the die back to be neither saved nor scored.
	 */
	public void reset()
	{
		saved = false;
		scored = false;
	}
	
	/**
	 * Rolls the die, if it is saved or scored the value will remain unchanged.
	 */
	public int roll()
	{
		if (saved || scored)
			return super.getCurrentValue();
		else
			return super.roll();
	}
	


	
	/**
	 * Returns the die as a string consisting of it's current state.
	 */
	public String toString()
	{
		return getCurrentValue() + "-" + saved + "-" + scored;
	}
}
