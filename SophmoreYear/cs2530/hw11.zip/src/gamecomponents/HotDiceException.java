package gamecomponents;
/**
 * Exception to indicate that the die are all scored and 
 * in a hot dice status.
 * 
 * @author Michael J. Holmes
 * @version 1.0 April 16, 2016
 *
 */
public class HotDiceException extends Exception {}
