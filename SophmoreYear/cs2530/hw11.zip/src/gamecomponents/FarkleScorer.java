package gamecomponents;

import java.util.ArrayList;

/**
 * Provides an interface for implementing different ways to score the game of Farkle.
 * @author holmesm
 *
 */
public interface FarkleScorer {
	/**
	 * Takes in dice to score and returns the points for the set of dice.  If it is not 
	 * a valid scoring combination an InvalidFarkleScoreException will be thrown.
	 *  
	 * @param diceToScore the dice that should be scored.
	 * @return the point total of the dice.
	 * @throws InvalidFarkleScoreException
	 */
	public int scoreDice(ArrayList<FarkleDie> diceToScore) throws InvalidFarkleScoreException;
	
	/**
	 * Takes in dice and checks to see if they are not scorable and a farkle.
	 * @param diceToCheck the dice to validate.
	 * @return true if the are farkled.
	 */
	public boolean farkled(ArrayList<FarkleDie> diceToCheck);

}
