package gamecomponents;

/**
 * Exception to indicate that the die passed into the scorer
 * is not a valid scoring combination.
 * 
 * @author Michael J. Holmes
 * @version 1.0 April 16, 2016
 *
 */
public class InvalidFarkleScoreException extends Exception {}
