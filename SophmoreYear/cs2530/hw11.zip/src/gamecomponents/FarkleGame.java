package gamecomponents;

import java.util.ArrayList;

/**
 * FarkleGame manages all of the elements of a game of Farkle, includeing the dice, players, scoring 
 * and controls the rounds.
 * 
 * @author Michael J. Holmes
 * @version 1.0  April 16,2016
 *
 */
public class FarkleGame {
	
	//-------------------------------------------
	// Instance Variables
	//-------------------------------------------
	private ArrayList<Player> players;
	private ArrayList<FarkleDie> dice;
	private FarkleScorer scorer;
	private int pointGoal;
	private int currentPlayer;
	private boolean lastRound;
	private int outPlayer;
	private int currentTurnScore;

	
	//--------------------------------------------
	// Constructors
	//--------------------------------------------
	/**
	 * Creates a new Farkle game with the provided players, scorer, dice and point goal.
	 * 
	 * @param somePlayers the Players for the game.
	 * @param someScorer the scorer to use in scoring the dice.
	 * @param someDice the dice to use for the game.
	 * @param somePointGoal the point goal of the game.
	 */
	public FarkleGame(ArrayList<Player> somePlayers, FarkleScorer someScorer, ArrayList<FarkleDie> someDice, int somePointGoal)
	{
		this(somePlayers,someScorer,someDice, somePointGoal,1,false,0,0);
	}
	
	/**
	 * Creates a Farkle game in progress with the provided values.
	 * 
	 * @param somePlayers the Players for the game.
	 * @param someScorer the scorer to use in scoring the dice.
	 * @param someDice the dice to use for the game.
	 * @param somePointGoal the point goal of the game.
	 * @param currentPlayerNumber the number of the player who's turn it is.
	 * @param isLastRound true if this is the last round, false otherwise.
	 * @param playerGoingOutNumber the number of the player that first went out to start the last round.
	 * @param currentTurnPoints the points that the current player has on the current turn.
	 */
	public FarkleGame(ArrayList<Player> somePlayers, FarkleScorer someScorer, ArrayList<FarkleDie> someDice, int somePointGoal,
			          int currentPlayerNumber, boolean isLastRound, int playerGoingOutNumber, int currentTurnPoints )
	{
		players = somePlayers;
		dice = someDice;
		scorer = someScorer;
		pointGoal = somePointGoal;
		currentPlayer = currentPlayerNumber-1;
		lastRound = isLastRound;
		outPlayer = playerGoingOutNumber-1;
		currentTurnScore = currentTurnPoints;
	}
	
	
	//--------------------------------------------------
	// Class Methods
	//--------------------------------------------------
	/**
	 * Returns the point goal for winning the game.
	 * @return the goal of points to get.
	 */
	public int getPointGoal(){
		return pointGoal;
	}
	
	/**
	 * Returns the score for the current turn.
	 * @return score for the current turn.
	 */
	public int getCurrentTurnScore(){
		return currentTurnScore;
	}
	
	/**
	 * Returns a string containing the current player, the current points for the turn and a list of all
	 * players and their total points.
	 * 
	 * @return a string containing the current scores of the game.
	 */
	public String getCurrentScores()
	{
		String output = "";
		
		if(players.size()>0){
		    output += "Current Player: " + players.get(currentPlayer).getName() + "\nCurrent turn score: " + currentTurnScore +"\n\n";
		
		    for (Player aPlayer : players){
			    output += aPlayer.getName() + "\t" + aPlayer.getCurrentScore() + "\n";
		    }
		}
		
		return output;
	}
	
	/**
	 * Checks to see if the game is in an end state.
	 * 
	 * @return true if the game is over, false if not.
	 */
	public boolean gameOver()
	{
		return (lastRound && (currentPlayer == outPlayer) && !tie());
	}
	
	
	/**
	 * Get's the name of the winning player.
	 * 
	 * @return the name of the winning player, or an empty string if there is currently no winner.
	 */
	public String getWinnerName()
	{
		if (gameOver())
			return getLeader();
		else
			return "";	
	}
	
	/**
	 * Rolls the dice and returns back the resulting dice.
	 * 
	 * @return the dice that were rolled.
	 * @throws FarkledException if the unsaved and unscored dice do not have a scorable result.
	 */
	public ArrayList<FarkleDie> rollDice() throws FarkledException
	{
		roll();
		
		if (scorer.farkled(getNonScoredDice()))
		{
			currentTurnScore = 0;
			throw new FarkledException();
		}
		
		return dice;	
	}
	
	/**
	 * When a player has met the point goal, there is one more round for the others players
	 * to try and beat the leader.  This method will return if the game is in this last round.
	 * 
	 * @return true if it is in the last round, false otherwise.
	 */
	public boolean lastRound()
	{
		return lastRound;
	}

	/**
	 * Get's the number of the current player.
	 * @return the number of the current player.
	 */
	public int getCurrentPlayer(){
		return currentPlayer+1;
	}
	
	/**
	 * If the game is in the last round, returns the player's number
	 * of the one going out.
	 * 
	 * @return the number of the player that is out.
	 */
	public int getPlayerGoingOut(){
		return outPlayer+1;
	}
	
	/**
	 * REturns the players in the game in an ArrayList.
	 * @return an ArrayList with the players.
	 */
	public ArrayList<Player> getPlayers(){
		return players;
	}
	
	/**
	 * Resets the game to a new game, using the existing players and point goal.
	 */
	public void reset()
	{
		currentPlayer = 0;
		lastRound = false;
		outPlayer = -1;
		currentTurnScore = 0;
		
		for (Player aPlayer : players)
			aPlayer.resetScore();
	}
	
	/**
	 * Scores the dice that have just been saved.  If the saved dice 
	 * 
	 * 
	 * @throws InvalidFarkleScoreException
	 * @throws HotDiceException
	 */
	public void scoreDice() throws InvalidFarkleScoreException, HotDiceException
	{
		int diceScore = scorer.scoreDice(getSavedDice());
		
		if (diceScore == 0)
		{
			throw new InvalidFarkleScoreException();
		}
		else
		{
			currentTurnScore += diceScore;
			updateScoredDice();
			
			if (hotDice())
			{
				resetDice();
				throw new HotDiceException();
			}
		}
	}
	
	/**
	 * Ends the current player's turn, updates the score and sets the
	 * next player to the current player.
	 * 
	 * If the player just reached the goal, it will set the last round indicator.
	 */
	public void endTurn()
	{
		players.get(currentPlayer).addToScore(currentTurnScore);
		
		if (!lastRound && players.get(currentPlayer).getCurrentScore() >= pointGoal)
		{
			lastRound = true;
			outPlayer = currentPlayer;
		}
			
		setNextPlayer();
	}
	
	/**
	 * Returns the dice that the game is using.
	 * 
	 * @return the dice.
	 */
	public ArrayList<FarkleDie> getDice()
	{
		return dice;
	}
	

	
	//------------------------------------------------
	// Private Helper Methods
	//------------------------------------------------
	/**
	 * Determines if the dice have all been scored and if the player has "hot dice".
	 * 
	 * @return true if all the dice have been successfully scored.
	 */
	private boolean hotDice()
	{
		for(FarkleDie die : dice)
		{
			if (!die.isScored())
				return false;
		}
		return true;
	}
	
	/**
	 * Gets the name of the current player in the lead.
	 * 
	 * @return the lead player's name.
	 */
	private String getLeader()
	{
		int maxScore = -1;
		String maxPlayerName = "";
		
		for(Player aPlayer : players)
		{
			if(aPlayer.getCurrentScore() > maxScore)
			{
				maxScore = aPlayer.getCurrentScore();
				maxPlayerName = aPlayer.getName();
			}
		}
		
		return maxPlayerName;
	}
	
	/**
	 * Determines if there are two or more players tied for the lead.
	 * 
	 * @return true if there is a tie score.
	 */
	private boolean tie()
	{
		int maxScore = -1;
		int secondPlace = -1;
		
		for(Player aPlayer : players)
		{
			if(aPlayer.getCurrentScore() >= maxScore)
			{
				secondPlace = maxScore;
				maxScore = aPlayer.getCurrentScore();
			}
		}
		
		return (maxScore == secondPlace);
	}
	
	/**
	 * Rolls all of the dice.
	 */
	private void roll()
	{
		for(FarkleDie die : dice)
		{
			die.roll();
		}
	}
	
	/**
	 * Returns the dice that have been saved.
	 * 
	 * @return the saved dice.
	 */
	private ArrayList<FarkleDie> getSavedDice()
	{
		ArrayList<FarkleDie> savedDice = new ArrayList<FarkleDie>();
		
		for(FarkleDie die : dice)
	    {
		    if (die.isSaved() && !die.isScored())
			{
				savedDice.add(die);
			}
	    }
		
		return savedDice;
	}
	
	/**
	 * Returns the dice that have not been scored.
	 * 
	 * @return the nonscored dice.
	 */
	private ArrayList<FarkleDie> getNonScoredDice()
	{
		ArrayList<FarkleDie> nonScoredDice = new ArrayList<FarkleDie>();
		
		for(FarkleDie die : dice)
	    {
		    if (!die.isScored())
			{
				nonScoredDice.add(die);
			}
	    }
		
		return nonScoredDice;
	}
	
	/**
	 * Sets the next player to be the current player, resets the turn score and resets the dice.
	 */
	private void setNextPlayer()
	{
		if ( (currentPlayer + 1) == players.size())
			currentPlayer = 0;
		else
			currentPlayer++;
		
		currentTurnScore = 0;
		resetDice();
	}
	
	/**
	 * Resets the dice to be nonsaved and nonscored.
	 */
	private void resetDice()
	{
		for(FarkleDie aDie : dice)
			aDie.reset();
	}
	
	/**
	 * Updates the dice that were saved and just scored to be scored.
	 */
	private void updateScoredDice()
	{
		for (FarkleDie aDie : dice)
		{
			if(aDie.isSaved())
			{
				aDie.setSave(false);
				aDie.setScored(true);
			}
		}
	}
}
