package gamecomponents;

/**
 * Exception to indicate that the die are non-scorable and 
 * in a Farkled status.
 * 
 * @author Michael J. Holmes
 * @version 1.0 April 16, 2016
 *
 */
public class FarkledException extends Exception {}
