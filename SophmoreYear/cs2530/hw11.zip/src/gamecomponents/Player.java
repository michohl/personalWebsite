package gamecomponents;

/**
 * Maintains the name and current score of a player.
 * 
 * @author Michael J. HOlmes
 * @version 1.0   April 16, 2016
 *
 */
public class Player {

	//----------------------------------------
	// Instance Variables
	//----------------------------------------
	private String name;
	private int currentScore;
	
	
	//-----------------------------------------
	// Constructors
	//-----------------------------------------
	/**
	 * Creates a player with the given name.
	 * 
	 * @param playerName the player's name.
	 */
	public Player(String playerName)
	{
		name = playerName;
		currentScore = 0;
	}
	
	
	//-----------------------------------------
	// Class Methods
	//-----------------------------------------
	
	/**
	 * Returns the name of the player.
	 * 
	 * @return player's name.
	 */
	public String getName()
	{
		return name;
	}
	
	/**
	 * Resets the player's score to 0.
	 */
	public void resetScore()
	{
		currentScore = 0;
	}
	
	/**
	 * Returns the player's current score.
	 * 
	 * @return player's current score.
	 */
	public int getCurrentScore()
	{
		return currentScore;
	}
	
	/**
	 * Update the player's score by adding the inputed points.
	 * 
	 * @param points the points to add to the player's score.
	 */
	public void addToScore(int points)
	{
		currentScore += points;
	}
	
}
