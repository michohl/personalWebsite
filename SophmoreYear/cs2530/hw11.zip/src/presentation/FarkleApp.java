package presentation;

import java.util.ArrayList;

import gamecomponents.*;
/**
 * The main program for the Farkle Application, it creates a frame and starts the game.
 * 
 * @author Michael J. Holmes
 * @version 1.0 April 16, 2016
 *
 */
public class FarkleApp {
	
	public static void main(String[] args)
	{
		FarkleFrame main = new FarkleFrame();
	}
	
	

}