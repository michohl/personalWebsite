package presentation;

import java.awt.*;
import javax.swing.*;
import java.util.ArrayList;
import gamecomponents.*;

/**
 * The DicePanel is a JPanel that holds any number of DiePanels inside of it.
 * This can be used to represent a collection of dice.
 * 
 * @author Michael J. Holmes
 * @version 1.0   December 17, 2015
 *
 */
public class FarkleDicePanel extends JPanel {
	
	//----------------------------------------
	// Instance Variables
	//----------------------------------------
	
	//----------------------------------------
	// Constructors
	//----------------------------------------

	public FarkleDicePanel(ArrayList<FarkleDie> theDice) {
		super();
		this.setPreferredSize(new Dimension(725,225));
		this.setLayout(new FlowLayout());
		
		for(FarkleDie aDie : theDice)
		{
			this.add(new FarkleDiePanel(aDie));
		}
	}
	
	/**
	 * Rolls all of the dice in the panel.
	 */
	public void rollDice(){
		FarkleDiePanel aDie;
		
		for(Component aComponent : this.getComponents())
		{
			try{
				aDie = (FarkleDiePanel) aComponent;
				aDie.rollDie();
			}
			catch (Exception e)
			{
				//Ignore any components within the panel that is not a BattleDiePanel.
			}
		}
	}
}
