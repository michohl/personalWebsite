package presentation;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.filechooser.*;
import dao.*;
import gamecomponents.*;

/**
 * The FarkleFrame class contains all of the components and control to play a game of Farkle.
 * 
 * @author Michael J. Holmes
 * @version 1.0  April 16, 2016
 *
 */
public class FarkleFrame extends JFrame 
{
	//-------------------------------------------
	// Instance Variables
	//-------------------------------------------
	private FarkleDicePanel dice;
	private ArrayList<FarkleDie> theDice;
	private JLabel scoreBoard;
	private JPanel controlPanel;
	private JButton rollButton, scoreButton, endTurnButton;
	private gamecomponents.FarkleGame game;
	private JMenuBar menuBar;
	
	//-------------------------------------------
    // Constructors
	//-------------------------------------------
	/**
	 * Construct the Farkle game and initialize to start.
	 */
	public FarkleFrame(){
		
		//Initialize the frame default settings.
		this.setSize(800, 600);
		this.setLayout(new GridLayout(3,0));
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setTitle("Farkle");

		//Create a default solitaire game.
		theDice = getDice();
		ArrayList<Player> solo = new ArrayList<Player>();
		solo.add(new Player("Solitaire"));
		game = new FarkleGame(solo,new StandardFarkleScorer(),theDice,5000);
		
		//Build the frame.
		addMenu();				
		addScoreboard();
		addControlPanel();
		addDicePanel();
		this.setVisible(true);
	}
	
	
	//-------------------------------------------
	// Class Methods
	//-------------------------------------------
	/**
	 * Create a new game, prompting for new players and point goal.
	 */
	private void newGame(){
		ArrayList<Player> players = getPlayers();
		FarkleScorer scorer = new StandardFarkleScorer();		
		game = new gamecomponents.FarkleGame(players,scorer,theDice,getGoal());
	}

	/**
	 * Prompts the user to enter a point goal for the game.
	 * 
	 * @return the point goal to use in the game.
	 */
	private int getGoal(){
		try{
			return Integer.valueOf(JOptionPane.showInputDialog(this,"Select a point goal: ","Target Points",JOptionPane.QUESTION_MESSAGE));
		}
		catch (Exception e){
			return 5000;
		}
	}
	
	/**
	 * Prompts the user to select a number of players, and then prompts the user
	 * to enter each player's name.
	 * 
	 * @return the players created based on the user input.
	 */
	private ArrayList<Player> getPlayers(){
		ArrayList<Player> players = new ArrayList<Player>();
		
		Object[] options = {1,2,3,4,5,6};
		int numPlayers = 0;
		numPlayers = (int) JOptionPane.showInputDialog(this,"Select a number of players: ","Players",JOptionPane.QUESTION_MESSAGE,null,options,1); 
		
		String name;
		for (int i=0; i<numPlayers;i++){
			name = JOptionPane.showInputDialog(this,"Enter player " + (i+1) + "'s name:");
			players.add(new Player(name));
		}
		
		return players;
	}
	
	/**
	 * Creates a set of Farkle Dice for the game.
	 * 
	 * @return the dice to use in the game.
	 */
	private ArrayList<FarkleDie> getDice(){
		ArrayList<FarkleDie> dice = new ArrayList<FarkleDie>();
		
		for(int i=0; i<6; i++)
			dice.add(new FarkleDie());
		
		return dice;
	}

	
	/**
	 * Updates the scoreboard to reflect the current state of the game.
	 */
	private void updateScoreboard()
	{
		String lastRound = "";
		if (game.lastRound())
			lastRound = "LAST ROUND<br><br>";
		
		
		scoreBoard.setText("<html>" + lastRound + "Playing to: " + game.getPointGoal() + "<br><br>" + game.getCurrentScores().replaceAll("\n", "<br>") + "</html>");
	}
	
	/**
	 * Builds the game menu bar and adds it to the frame.
	 */
	private void addMenu()
	{
		menuBar = new JMenuBar();
		JMenu gameMenu = new JMenu("Game");
		JMenuItem newGameMenuItem = new JMenuItem("New");
		newGameMenuItem.addActionListener(new NewGameListener());
		JMenuItem resetGameMenuItem = new JMenuItem("Reset");
		resetGameMenuItem.addActionListener(new ResetGameListener());
		
		JMenuItem loadGameMenuItem = new JMenuItem("Load Game");
		loadGameMenuItem.addActionListener(new LoadGameListener());
		
		JMenuItem saveGameMenuItem = new JMenuItem("Save Game");
		saveGameMenuItem.addActionListener(new SaveGameListener());
		
		gameMenu.add(newGameMenuItem);
		gameMenu.add(resetGameMenuItem);
		
		gameMenu.add(loadGameMenuItem);
		gameMenu.add(saveGameMenuItem);
		menuBar.add(gameMenu);
		setJMenuBar(menuBar);
	}
	
	/**
	 * Creates a new DicePanel and ads it to the frame.
	 */
	private void addDicePanel()
	{
		dice = new FarkleDicePanel(theDice);
		dice.setVisible(false);
		this.add(dice);
	}
	
	/**
	 * Creates the player's control panel with the buttons they will
	 * use to interact with the game.
	 */
	private void addControlPanel(){
	  controlPanel = new JPanel();
	  controlPanel.setSize(800,100);
	  controlPanel.setLayout(new FlowLayout());
	
	  rollButton = new JButton("Roll");
	  rollButton.addActionListener(new RollListener());
	  controlPanel.add(rollButton);
	
	  scoreButton = new JButton("Score");
	  scoreButton.addActionListener(new ScoreListener());
	  scoreButton.setEnabled(false);
	  controlPanel.add(scoreButton);
	
	  endTurnButton = new JButton("End Turn");
	  endTurnButton.addActionListener(new EndTurnListener());
	  endTurnButton.setEnabled(false);
	  controlPanel.add(endTurnButton);
	
	  this.add(controlPanel);
	}
	
	/**
	 * Creates the scoreboard as a label and adds it to the frame.
	 */
	private void addScoreboard(){
		scoreBoard = new JLabel();

		this.add(scoreBoard);
		updateScoreboard();
	}
	
    /**
    * Updates the controls by enabling or disabling the buttons and dice on the frame 
    * and repaints it.
    *    
    * @param diceVisible determines if the dice are visible.
    * @param rollEnabled determines if the roll button is enabled.
    * @param scoreEnabled determines if the score button is enabled.
    * @param endTurnEnabled determines if the end turn button is enabled.
    */
	private void updateAndRepaint(boolean diceVisible, boolean rollEnabled, boolean scoreEnabled, boolean endTurnEnabled)
	{
		dice.setVisible(diceVisible);
		updateScoreboard();
		rollButton.setEnabled(rollEnabled);
		scoreButton.setEnabled(scoreEnabled);
		endTurnButton.setEnabled(endTurnEnabled);
		FarkleFrame.this.validate();
		FarkleFrame.this.repaint();
	}
	
    //-------------------------------------------
	// Private helper Inner classes
	//-------------------------------------------
	/**
	 * The RollListner responds when a user clicks the roll button.
	 * It rolls the dice, activates the dice on the screen and enables
	 * the buttons for the user to select dice to score.
	 * 
	 *@author Michael J. Holmes
	 *@ver 1.0 April 16, 2016
	 *
	 */
	private class RollListener implements ActionListener
	{

		@Override
		public void actionPerformed(ActionEvent e) {
			try 
			{
				dice.setVisible(true);
				game.rollDice();
				updateAndRepaint(true,false,true,false);
			} 
			catch (FarkledException ex) 
			{
				updateAndRepaint(true,false,false,true);
				JOptionPane.showMessageDialog(FarkleFrame.this,"Oh no!  You Farkled!","Farkled!",JOptionPane.WARNING_MESSAGE);
			}
			
		}
	}
	
	/**
	 * The ScoreListener responds when a user clicks the score button.
	 * If is it a valid scoring combination the turn score will be updated,
	 * and the dice scored.
	 * 
	 * @author Michael J. Holmes
	 * @ver April 16, 2016
	 *
	 */
	private class ScoreListener implements ActionListener
	{

		@Override
	  public void actionPerformed(ActionEvent arg0) {
			try 
			{
				game.scoreDice();
				updateAndRepaint(true,true,true,true);	
			} 
			catch (InvalidFarkleScoreException e) 
			{
				JOptionPane.showMessageDialog(FarkleFrame.this,"That is not a valid scoring combination! Try again.","Invalid!",JOptionPane.WARNING_MESSAGE);
			}
			catch (HotDiceException e1) 
			{
				updateAndRepaint(false,true,false,true);
				JOptionPane.showMessageDialog(FarkleFrame.this,"You've got hot dice!","Hot Dice!",JOptionPane.INFORMATION_MESSAGE);	
			}
			
			
		}
	}
	
	/**
	 * Listener to respond to the End Turn button click.
	 * @author Michael J. Holmes
	 * @ver 1.0 April 16, 2016
	 *
	 */
	private class EndTurnListener implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent arg0) {
	
				game.endTurn();
				
				if(game.gameOver())
				{
					updateAndRepaint(false,false,false,false);
					JOptionPane.showMessageDialog(FarkleFrame.this,game.getWinnerName() +" Wins!","Game Over",JOptionPane.INFORMATION_MESSAGE);
					
				}
				else
				{
					updateAndRepaint(false,true,false,false);
				}
		}
	}
	
	/**
	 * The NewGameListener responds when the user selects a new game from the menu.
	 *
	 */
	private class NewGameListener implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent arg0) {
			newGame();
			
			updateAndRepaint(false,true,false,false);		
		}
		
	}
	
	/**
	 * The ResetGameListener responds when the user selects reset from the menu.
	 *
	 */
	private class ResetGameListener implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent arg0) {
			game.reset();
			updateAndRepaint(false,true,false,false);
		}
		
	}
	
	
	
	
	
	/**
	 * The LoadGameListenter responds when the user selects to load a game from the menu.
	 *
	 */
	private class LoadGameListener implements ActionListener{
	       
		  public void actionPerformed(ActionEvent e) {
			   //Creates a file chooser, sets it to filter for .farkle files and displays it above the menubar.
	    	   JFileChooser myFileChooser = new JFileChooser();
	    	   myFileChooser.setFileFilter(new FileNameExtensionFilter("FARKLE FILES", "farkle", "farkle"));
	    	   int returnVal = myFileChooser.showOpenDialog(menuBar);
	    	   
	    	   //If the users approved the filechooser by clicking open.
	           if (returnVal == JFileChooser.APPROVE_OPTION) {
	                
	        	    File userFile = myFileChooser.getSelectedFile();
	        	    
	//==============================================================
	//TODO: Change this to use your FarkleFileDAO class instance.   
	//==============================================================
	                FarkleDAO dao = new NonFunctionalFarkleDAO();
	                
	                try {
	                	//Load the game file.
						game = dao.loadGame(userFile.toString());
						
						//Recreate the dice to use the newly loaded dice.
						FarkleFrame.this.getContentPane().remove(dice); //remove the old dice
						theDice = game.getDice();                       //recreate the dice
						dice = new FarkleDicePanel(theDice);	        //create a new dice panel with the new dice
						FarkleFrame.this.getContentPane().add(dice);    //add the new dice panel to the frame.
						FarkleFrame.this.validate();                    //tell the frame to validate the new panel.
						
						//If there was no score, start with a new turn.
						if(game.getCurrentTurnScore()==0){
							updateAndRepaint(false,true,false,false);
						}
						//else start in the middle of a turn.
						else{
							updateAndRepaint(true,true,true,true);
						}
						
					
					} catch (IOException e1) {
						JOptionPane.showMessageDialog(FarkleFrame.this,"File is invalid.","Error!",JOptionPane.ERROR_MESSAGE);	
					}
	                
	            } 
	    	   
	       }
	}
	
	/**
	 * The SaveGameListenter responds when the user selects to save a game from the menu.
	 *
	 */
	private class SaveGameListener implements ActionListener{
	       
		  public void actionPerformed(ActionEvent e) {
			   //Creates a file chooser, sets it to filter for .farkle files and displays it above the menubar.
	    	   JFileChooser myFileChooser = new JFileChooser();
	    	   myFileChooser.setFileFilter(new FileNameExtensionFilter("FARKLE FILES", "farkle", "farkle"));
	    	   int returnVal = myFileChooser.showSaveDialog(menuBar);
	    	   
	    	   //If the users approved the filechooser by clicking save.
	           if (returnVal == JFileChooser.APPROVE_OPTION) {
	                File userFile = myFileChooser.getSelectedFile();

	                
 //==============================================================
 //TODO: Change this to use your FarkleFileDAO class instance.   
 //==============================================================
   	                FarkleDAO dao = new NonFunctionalFarkleDAO();
	                
	                try {
	                	//Load the game file.
						dao.saveGame(game, userFile.toString()+".farkle");
						JOptionPane.showMessageDialog(FarkleFrame.this, "You game has been saved.","Saved",JOptionPane.INFORMATION_MESSAGE);
					} catch (IOException e1) {
						JOptionPane.showMessageDialog(FarkleFrame.this,"Error saving game.","Error!",JOptionPane.ERROR_MESSAGE);	
					}
	                
	            } 
	    	   
	       }
	}
	
	
	
	
	
}
