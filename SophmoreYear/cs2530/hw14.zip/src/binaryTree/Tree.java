package binaryTree;

import playingcards.standardcards.*;

public interface Tree {
	//
	//methods
	//
	
	void add(StandardPlayingCard myCard);
	
	void clear();
	
	boolean exists(StandardPlayingCard myCard);
	
	int height();

}
