package binaryTree;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import binaryTree.*;
import playingcards.*;
import playingcards.standardcards.*;

public class BinaryTreeTest {
	
	private StandardPlayingCard card1;
	private StandardPlayingCard card2;
	private StandardPlayingCard card3;
	private StandardPlayingCard card4;
	private StandardPlayingCard card5;
	private StandardPlayingCard card6;
	private StandardPlayingCard card7;
	private StandardPlayingCard card8;
	private Suit mySuit;
	private Rank myRank;
	private BinaryTree myTree;

	@Before
	public void setUp() throws Exception {
		//fully aware I wrote 3x the lines I needed by declaring mySuit and myRank every time.
		mySuit = Suit.SPADE;
		myRank = Rank.SEVEN;
		card1 = new StandardPlayingCard(mySuit,myRank);
		
		mySuit = Suit.DIAMOND;
		myRank = Rank.FOUR;
		card2 = new StandardPlayingCard(mySuit,myRank);
		
		mySuit = Suit.CLUB;
		myRank = Rank.SIX;
		card3 = new StandardPlayingCard(mySuit,myRank);
		
		mySuit = Suit.HEART;
		myRank = Rank.EIGHT;
		card4 = new StandardPlayingCard(mySuit,myRank);
		
		mySuit = Suit.HEART;
		myRank = Rank.KING;
		card5 = new StandardPlayingCard(mySuit,myRank);
		
		mySuit = Suit.HEART;
		myRank = Rank.FIVE;
		card6 = new StandardPlayingCard(mySuit,myRank);
		
		
		mySuit = Suit.HEART;
		myRank = Rank.SEVEN;
		card7 = new StandardPlayingCard(mySuit,myRank);
		
		mySuit = Suit.CLUB;
		myRank = Rank.TWO;
		card8 = new StandardPlayingCard(mySuit,myRank);
		
		myTree = new BinaryTree();
		
		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAdd() {
		myTree.add(card1);
		String rootString = myTree.getRootString();
		assertEquals("7 of spades() ()",rootString.toLowerCase());
		//assertEquals(card1.toString() + " () ()",rootString.toLowerCase());
		
	}

	@Test
	public void testClear() {
		myTree.add(card1);
		myTree.add(card2);
		myTree.add(card3);
		myTree.clear();
		String rootString = myTree.getRootString();
		assertEquals("",rootString);
	}

	@Test
	public void testExists() {
		myTree.add(card1);
		myTree.add(card2);
		myTree.add(card3);
		myTree.add(card4);
		myTree.add(card5);
		myTree.add(card6);
		myTree.add(card7);
		myTree.add(card8);
	
		assertTrue(myTree.exists(card1)); //checking root
		assertTrue(myTree.exists(card2)); //checking going right
		assertTrue(myTree.exists(card3)); //checking going left
	}

	@Test
	public void testHeight() {
		myTree.add(card1);
		myTree.add(card2);
		myTree.add(card3);
		myTree.add(card4);
		myTree.add(card5);
		myTree.add(card6);
		myTree.add(card7);
		myTree.add(card8);
		
		assertEquals(5,myTree.height());
	}

}
