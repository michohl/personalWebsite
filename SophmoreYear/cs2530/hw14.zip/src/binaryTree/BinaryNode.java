package binaryTree;

import playingcards.standardcards.StandardPlayingCard;




public class BinaryNode implements Tree{
	//
	//instance
	//
	private StandardPlayingCard card;
	private Tree left;
	private Tree right;
	
	//
	//constructors
	//
	public BinaryNode(StandardPlayingCard myCard){
		card = myCard;
		right = new NullNode();
		left = new NullNode();


	}


	
	//
	//methods
	//
	

	@Override
	public void add(StandardPlayingCard myCard) {
		if (myCard.compareTo(card)==0){
			//????wat do if equal????
		}
		
		if (myCard.compareTo(card)==1){
			if(left.height()==0){
				left = new BinaryNode(myCard);
			}
			else{
				left.add(myCard);
			}
		}
		
		if (myCard.compareTo(card)==-1){
			if(right.height()==0){
				right = new BinaryNode(myCard);
			}
			else{
				right.add(myCard);
			}
		}

		
	}



	@Override
	public void clear() {
		// done in BinaryTree.java
		
	}
	
	//for testing
	@Override
	public String toString(){
		return card + "("+ left.toString() + ") (" + right.toString() + ")";
		//string.toLowerCase()
		//Seven of Diamonds () ()
	}



	@Override
	public boolean exists(StandardPlayingCard myCard) {
		if (myCard.compareTo(card)==0){
			return true;
		}
		
		else if (myCard.compareTo(card)==1){
			return left.exists(myCard);
		}
		
		//if (myCard.compareTo(card)==-1){
		else{
			return right.exists(myCard);
		}
		
		
		

	}



	@Override
	public int height() {
		return 1+Math.max(left.height(),right.height());
	}

}
