package binaryTree;

import playingcards.standardcards.StandardPlayingCard;


public class NullNode implements Tree{
	//
	//instance
	//
	@SuppressWarnings("unused")
	private StandardPlayingCard card;
	@SuppressWarnings("unused")
	private Tree left;
	@SuppressWarnings("unused")
	private Tree right;
	
	//
	//constructors
	//
	public NullNode(){;
		card = null;
		left = null;
		right = null;


	}
	//
	//methods
	//
	
	//for testing
	@Override
	public String toString(){
		return "";
	}
	

	@Override
	public void add(StandardPlayingCard myCard) {
		// Does nothing right???
		
	}

	@Override
	public void clear() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean exists(StandardPlayingCard myCard) {
		// TODO Auto-generated method stub
		//should this return false or does null do the same thing?
		return false;
	}

	@Override
	public int height() {
		// TODO Auto-generated method stub
		return 0;
	}
}
