package binaryTree;

import playingcards.standardcards.StandardPlayingCard;




public class BinaryTree implements Tree {
	//
	//instance variables
	//
	Tree root;
	//private Tree left;
	//private Tree right;
	
	//
	//constructors
	//
	public BinaryTree(StandardPlayingCard myCard){
		root = new BinaryNode(myCard);
		//left = new NullNode();
		//right = new NullNode();
	}
	
	public BinaryTree(){
		root = new NullNode();	
	}
	
	//
	//methods
	//
	@Override
	public void add(StandardPlayingCard myCard) {
		if(root.height()==0){
			root = new BinaryNode(myCard);
		}
		else{
			root.add(myCard);
		}
		
	}

	@Override
	public void clear() {
		root = new NullNode();
		//left = null;
		//right = null;
		
	}

	@Override
	public boolean exists(StandardPlayingCard myCard) {
		// TODO Auto-generated method stub
		return root.exists(myCard);
	}

	@Override
	public int height() {
		//return 1+Math.max(left.height(), right.height());
		return root.height();
	}	
	
	//
	//test methods
	//
	
	public String getRootString(){
		return root.toString();
	}
	
	@Override
	public String toString(){
		return root.toString();
	}


	




}
