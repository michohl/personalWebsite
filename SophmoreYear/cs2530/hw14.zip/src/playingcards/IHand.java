package playingcards;

public interface IHand extends Comparable<IHand>, IDeckOfCards
{

}
