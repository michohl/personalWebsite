package playingcards;

public interface IPlayingCard extends Comparable<IPlayingCard>
{

}
