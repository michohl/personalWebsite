package playingcards.standardcards;

import playingcards.IPlayingCard;

public class StandardPlayingCard implements IPlayingCard
{

    //----------------------------------------------
    // Instance Variable
    //----------------------------------------------
    private Suit cardSuit;
    private Rank cardRank;
    
    
    //----------------------------------------------
    // Constructor
    //----------------------------------------------  
    
    public StandardPlayingCard()
    {
        cardSuit = Suit.HEART;
        cardRank = Rank.KING;
    }
    
    public StandardPlayingCard(Suit aSuit, Rank aRank)
    {
        cardSuit = aSuit;
        cardRank = aRank;
    }
    
        
    
   
    public int compareTo(IPlayingCard o)
    {
        if(o.getClass() == this.getClass())
        {
            StandardPlayingCard otherCard = (StandardPlayingCard) o;  //recast object
            
            if (this.getSuitValue() > otherCard.getSuitValue())
                return -1;
           
            else if (this.getSuitValue() < otherCard.getSuitValue())
                return 1;
            
            else
            {
                if (this.getRankValue() > otherCard.getRankValue())
                    return -1;
                else if (this.getRankValue() < otherCard.getRankValue())
                    return 1;
                else
                    return 0;
            }   
        }
        else //It's some other type of Card.
        {
            return -1;  
        }
    }
    
    public String toString()
    {
        return getRankName() +  " of " + getSuitName();
    }
    
    
    
    
    //-----------------------------------------------
    // Private helper functions
    //----------------------------------------------
    private int getRankValue()
    {
            switch (cardRank) 
            {
                case ACE:
                    return 1;
                        
                case TWO:
                    return 2;
                
                case THREE:
                    return 3;
                    
                case FOUR:
                    return 4;
                    
                case FIVE:
                    return 5;
                    
                case SIX:
                    return 6;
                    
                case SEVEN:
                    return 7;
                    
                case EIGHT:
                    return 8;
                    
                case NINE:
                    return 9;
                    
                case TEN:
                    return 10;
                    
                case JACK:
                    return 11;
                    
                case QUEEN:
                    return 12;
                    
                case KING:
                    return 13;
                    
                default:
                    return 0;
            }
    }
        
    private int getSuitValue()
    {
            switch (cardSuit) 
            {
                case CLUB:
                    return 1;
                        
                case HEART:
                    return 2;
                
                case SPADE:
                    return 3;
                    
                case DIAMOND:
                    return 4;
                    
                default:
                    return 0;
            }

    }
    
    private String getRankName()
    {
            switch (cardRank) 
            {
                case ACE:
                    return "Ace";
                        
                case TWO:
                    return "2";
                
                case THREE:
                    return "3";
                    
                case FOUR:
                    return "4";
                    
                case FIVE:
                    return "5";
                    
                case SIX:
                    return "6";
                    
                case SEVEN:
                    return "7";
                    
                case EIGHT:
                    return "8";
                    
                case NINE:
                    return "9";
                    
                case TEN:
                    return "10";
                    
                case JACK:
                    return "Jack";
                    
                case QUEEN:
                    return "Queen";
                    
                case KING:
                    return "King";
                    
                default:
                    return "Blank";
            }
    }

    private String getSuitName()
    {
            switch (cardSuit) 
            {
                case CLUB:
                    return "Clubs";
                        
                case HEART:
                    return "Hearts";
                
                case SPADE:
                    return "Spades";
                    
                case DIAMOND:
                    return "Diamond";
                    
                default:
                    return "Nothing";
            }

    }

}
