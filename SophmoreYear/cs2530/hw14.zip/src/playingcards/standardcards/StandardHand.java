package playingcards.standardcards;

import java.util.ArrayList;

import playingcards.IHand;

public class StandardHand extends StandardDeck implements IHand
{

    //------------------------------
    // Instance Variables
    //------------------------------
    
    
    
    //------------------------------
    // Constructors
    //------------------------------
    public StandardHand()
    {
        reset();
    }
    
    
    
    
    //------------------------------
    // Class Methods
    //------------------------------
   
    
    
    

    public int compareTo(IHand o)
    {
        return 0;
    }


    @Override
    public void reset()
    {
        myCards.clear();

    }
    
}