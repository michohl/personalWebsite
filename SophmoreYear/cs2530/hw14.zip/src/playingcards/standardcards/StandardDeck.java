package playingcards.standardcards;

import java.io.IOException;
import java.util.ArrayList;

import playingcards.IDeckOfCards;
import playingcards.IHand;
import playingcards.IPlayingCard;
import playingcards.OutOfCardsException;

public class StandardDeck implements IDeckOfCards
{
    //------------------------------
    // Instance Variables
    //------------------------------
    protected ArrayList<IPlayingCard> myCards;
    protected ArrayList<IPlayingCard> initialCards;
    
    
    //------------------------------
    // Constructors
    //------------------------------
    public StandardDeck()
    {
        myCards = new ArrayList<IPlayingCard>();
        initialCards = new ArrayList<IPlayingCard>();
    }
    
    
    
    
    //------------------------------
    // Class Methods
    //------------------------------
   
    public IPlayingCard drawCard()
    {
        IPlayingCard topCard = myCards.get(0); //Save top card.
        myCards.remove(0); //remove it from deck
        
        return topCard;
    }


    public void add(IPlayingCard cardToAdd)
    {
        myCards.add(cardToAdd);
    }


    public void add(IPlayingCard[] cardsToAdd)
    {
        
        for (IPlayingCard aCard : cardsToAdd)
        {
            add(aCard);
        }
    }


    
    public void add(IDeckOfCards cardsToAdd)
    {
       while (!cardsToAdd.isEmpty())
       {
           try {
			add(cardsToAdd.drawCard());
		} catch (OutOfCardsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       }

    }


    
    public void shuffle()
    {
        java.util.Collections.shuffle(myCards);
    }


    
    public void sort()
    {
        java.util.Collections.sort(myCards);

    }


    
    public IHand[] dealCards(int numOfHands)
    {
        IHand[] handsToReturn = new StandardHand[numOfHands];
        
        for (int count=0; count<handsToReturn.length;count++)
        {
            handsToReturn[count] = new StandardHand();
        }
        
        
        while(!this.isEmpty())
        {
            for(int i =0; i < handsToReturn.length; i++)
            {
                if (this.isEmpty())
                    break;
                else
                  handsToReturn[i].add(this.drawCard());
            }
        }
        
        return handsToReturn;
    }


    
    public IHand[] dealCards(int numOfHands, int numOfCards)
    {
        IHand[] handsToReturn = new StandardHand[numOfHands];
        
       
        for (int count=0; count<handsToReturn.length;count++)
        {
            handsToReturn[count] = new StandardHand();
        }
        
        
        for(int j=0;j<numOfCards;j++)
        {
            if(this.isEmpty())
                break;
            else
            {
                for(int i=0; i < handsToReturn.length; i++)
                {
                    if (this.isEmpty())
                        break;
                    else
                        handsToReturn[i].add(this.drawCard());
                }
            }
        }
        
        return handsToReturn;
    }


    
    public boolean isEmpty()
    {
        return myCards.isEmpty();
    }


    
    public void reset()
    {
        
        myCards.clear();
        
        for(IPlayingCard card : initialCards)
        {
        	this.add(card);
        }
    }
    
    public String toString()
    {
        
        StringBuffer output = new StringBuffer();
        
        for(IPlayingCard aCard: myCards)
        {
            output.append(aCard.toString());
            output.append(" ");
        }
        
        return output.toString();
    }
}
