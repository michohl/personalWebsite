package playingcards.standardcards;

public enum Suit
{
     HEART, DIAMOND, SPADE, CLUB
}
