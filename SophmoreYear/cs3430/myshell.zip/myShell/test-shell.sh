#!/bin/bash

#Estabalish the environment:
echo 'Displaying my $PATH - do you parse it?'
echo $PATH
echo 
echo '-----------------------------------------------------------------------'
echo

echo 'which myecho - will your code find it?'
which myecho
echo 
echo '-----------------------------------------------------------------------'
echo

# Test #1. Your shell should not take any arguments.
echo 'Testing if your code takes arguments.  Usage'
./myshell should not take args
echo 
echo '-----------------------------------------------------------------------'
echo

# Test #2. Your shell should find myecho
echo 'Testing if your code finds myecho in /home/gray/bin (part of my PATH)'
./myshell << MYECHO
myecho can you find it
quit
exit
MYECHO
echo 
echo '-----------------------------------------------------------------------'
echo

# Test #3. Make sure that you're using exec calls:
echo 'Testing to see if you are using exec calls in your code'
grep -C2 exec myshell* 2>/dev/null
echo 
echo '-----------------------------------------------------------------------'
echo

# Test #4 commands with arguments and exit
echo 'Testing to see if you are correctly handling arguments'
./myshell << CMDWITHARGS
ls -l /boot
quit
exit
CMDWITHARGS
echo 
echo '-----------------------------------------------------------------------'
echo

#Test #5. How do you handle non-existant commands?
./myshell << DOESNOTEXIST
doesnotexits
quit
exit
DOESNOTEXIST
echo 
echo '-----------------------------------------------------------------------'
echo

#Test #6 - Absolute path handling.
./myshell << ABSOLUTE
/sbin/ifconfig eth0
quit
exit
ABSOLUTE

